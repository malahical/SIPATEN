<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Dinas extends Model
{
    protected $fillable = [
        'nama_dinas',
        'no_wa_admin',
    ];

    public function users(): HasMany
    {
        return $this->hasMany(User::class, 'dinas_id');
    }

    public function layanans(): HasMany
    {
        return $this->hasMany(Layanan::class, 'dinas_id');
    }
}
