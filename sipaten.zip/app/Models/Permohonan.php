<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Permohonan extends Model
{
    protected $fillable = [
        'nomor_registrasi',
        'layanan_id',
        'kecamatan_id',
        'operator_id',
        'nama_pemohon',
        'nik',
        'alamat',
        'no_wa_pemohon',
        'status',
        'catatan_terakhir',
    ];

    public function layanan(): BelongsTo
    {
        return $this->belongsTo(Layanan::class);
    }

    public function kecamatan(): BelongsTo
    {
        return $this->belongsTo(Kecamatan::class);
    }

    public function operator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'operator_id');
    }

    public function files(): HasMany
    {
        return $this->hasMany(PermohonanFile::class);
    }

    public function statusLogs(): HasMany
    {
        return $this->hasMany(StatusLog::class);
    }

    public function billings(): HasMany
    {
        return $this->hasMany(Billings::class);
    }

    public function notificationLogs(): HasMany
    {
        // Phase 4 - nanti ditambah notification relasi
        // placeholder route belum dibuat
        return $this->hasMany(NotificationLog::class);
    }
}
