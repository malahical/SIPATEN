<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Layanan extends Model
{
    protected $fillable = [
        'nama_layanan',
        'jenis_layanan',
        'dinas_id',
        'sla_hari',
        'persyaratan',
        'is_active',
    ];

    public function dinas(): BelongsTo
    {
        return $this->belongsTo(Dinas::class, 'dinas_id');
    }
}
