<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Billings extends Model
{
    protected $fillable = [
        'permohonan_id',
        'nomor_billing',
        'jenis_billing',
        'nominal',
        'tanggal_billing',
        'batas_bayar',
        'status_bayar',
        'catatan',
        'created_by',
    ];

    public function permohonan(): BelongsTo
    {
        return $this->belongsTo(Permohonan::class);
    }
}
