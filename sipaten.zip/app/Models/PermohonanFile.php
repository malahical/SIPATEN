<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PermohonanFile extends Model
{
    protected $fillable = [
        'permohonan_id',
        'nama_file',
        'jenis_file',
        'drive_file_id',
        'drive_url',
        'uploaded_by',
    ];

    public function permohonan(): BelongsTo
    {
        return $this->belongsTo(Permohonan::class);
    }

    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
