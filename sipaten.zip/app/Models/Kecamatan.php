<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Kecamatan extends Model
{
    protected $fillable = [
        'nama_kecamatan',
        'alamat',
    ];

    public function users(): HasMany
    {
        return $this->hasMany(User::class, 'kecamatan_id');
    }
}
