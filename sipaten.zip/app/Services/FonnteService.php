<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class FonnteService
{
    public function __construct(
        private ?string $token = null,
        private ?string $url = null,
    ) {
        // Let constructor set values freely (avoid mutating readonly properties).
        $this->token = $this->token ?? env('FONNTE_TOKEN');
        $this->url = $this->url ?? env('FONNTE_URL');
    }

    public function normalizeNumber(?string $number): ?string
    {
        if ($number === null) {
            return null;
        }

        $clean = preg_replace('/[^0-9]/', '', trim($number)) ?: '';

        if ($clean === '') {
            return null;
        }

        // If starts with 0 -> change to 62 (Indonesia)
        if (str_starts_with($clean, '0')) {
            $clean = '62' . substr($clean, 1);
        }

        // If already starts with 62, keep it
        if (str_starts_with($clean, '62')) {
            return $clean;
        }

        // Otherwise, assume it's already in international format
        return $clean;
    }

    public function sendWA(?string $toNumber, string $message): array
    {
        $toNumber = $this->normalizeNumber($toNumber);

        if (!$toNumber) {
            return [
                'success' => false,
                'response_status' => null,
                'response_body' => 'Invalid phone number',
            ];
        }

        $token = $this->token;
        $url = $this->url;

        if (!$token || !$url) {
            return [
                'success' => false,
                'response_status' => null,
                'response_body' => 'Missing FONNTE_TOKEN or FONNTE_URL',
            ];
        }

        try {
            // Typical Fonnte API example:
            // POST {url} with query/header: Authorization: token and fields: target, message
            $resp = Http::timeout(20)
                ->withToken($token)
                ->asForm()
                ->post($url, [
                    'target' => $toNumber,
                    'message' => $message,
                ]);

            return [
                'success' => $resp->successful(),
                'response_status' => (string) $resp->status(),
                'response_body' => (string) $resp->body(),
            ];
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'response_status' => null,
                'response_body' => $e->getMessage(),
            ];
        }
    }
}
