<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;

class GoogleDriveService
{
    /**
     * Upload file ke Google Drive via helper endpoint (GAS) jika tersedia.
     *
     * Karena OAuth/Google SDK belum ditambahkan sebagai dependency, implementasi ini bersifat
     * env-guarded dan aman dijalankan tanpa integrasi penuh.
     *
     * Environment (opsional):
     * - GAS_UPLOAD_URL (endpoint Apps Script helper untuk upload ke Drive)
     *
     * Return: ['drive_file_id' => ?string, 'drive_url' => ?string]
     */
    public function uploadFile(UploadedFile $file, array $folderPathParts): array
    {
        // Guard: jika belum ada helper endpoint, fallback.
        $gasUploadUrl = env('GAS_UPLOAD_URL');
        if (!is_string($gasUploadUrl) || trim($gasUploadUrl) === '') {
            return [
                'drive_file_id' => null,
                'drive_url' => null,
            ];
        }

        // Build payload. GAS diharapkan menangani upload & folder creation.
        $fileContents = file_get_contents($file->getRealPath());
        if ($fileContents === false) {
            return [
                'drive_file_id' => null,
                'drive_url' => null,
            ];
        }

        $fileBase64 = base64_encode($fileContents);

        $folderPath = implode('/', array_filter($folderPathParts, fn ($p) => $p !== null && $p !== ''));

        try {
            $resp = Http::timeout(60)->post($gasUploadUrl, [
                'folderPath' => $folderPath,
                'file' => [
                    'name' => $file->getClientOriginalName(),
                    'mime' => $file->getClientMimeType(),
                    'base64' => $fileBase64,
                ],
            ]);

            if (!$resp->ok()) {
                return [
                    'drive_file_id' => null,
                    'drive_url' => null,
                ];
            }

            $data = $resp->json();

            return [
                'drive_file_id' => $data['drive_file_id'] ?? null,
                'drive_url' => $data['drive_url'] ?? null,
            ];
        } catch (\Throwable $e) {
            return [
                'drive_file_id' => null,
                'drive_url' => null,
            ];
        }
    }
}
