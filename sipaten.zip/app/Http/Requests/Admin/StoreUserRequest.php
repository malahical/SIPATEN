<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class StoreUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'admin';
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email:rfc,dns', 'max:255', 'unique:users,email'],
            'role' => ['required', 'in:operator,verifikator,admin'],
            'kecamatan_id' => ['nullable', 'integer', 'exists:kecamatans,id'],
            'dinas_id' => ['nullable', 'integer', 'exists:dinases,id'],
            'no_wa' => ['nullable', 'string', 'max:30'],
            'is_active' => ['required', 'boolean'],
            'password' => ['required', Password::defaults()],
        ];
    }
}
