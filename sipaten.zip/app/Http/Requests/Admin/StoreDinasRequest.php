<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreDinasRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'admin';
    }

    public function rules(): array
    {
        return [
            'nama_dinas' => ['required', 'string', 'max:255'],
            'no_wa_admin' => ['nullable', 'string', 'max:30'],
        ];
    }
}
