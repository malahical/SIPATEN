<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreLayananRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'admin';
    }

    public function rules(): array
    {
        return [
            'nama_layanan' => ['required', 'string', 'max:255'],
            'jenis_layanan' => ['required', 'string', 'max:50'],
            'dinas_id' => ['required', 'integer', 'exists:dinases,id'],
            'sla_hari' => ['required', 'integer', 'min:1'],
            'persyaratan' => ['nullable', 'string'],
            'is_active' => ['required', 'boolean'],
        ];
    }
}
