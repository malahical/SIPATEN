<?php

namespace App\Http\Requests\Verifikator;

use Illuminate\Foundation\Http\FormRequest;

class UpsertBillingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'nomor_billing' => ['nullable', 'string', 'max:255'],
            'jenis_billing' => ['nullable', 'string', 'max:255'],
            'nominal' => ['nullable', 'numeric'],
            'tanggal_billing' => ['nullable', 'date'],
            'batas_bayar' => ['nullable', 'date'],
            'catatan' => ['nullable', 'string'],
        ];
    }
}
