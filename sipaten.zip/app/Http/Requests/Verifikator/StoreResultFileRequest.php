<?php

namespace App\Http\Requests\Verifikator;

use Illuminate\Foundation\Http\FormRequest;

class StoreResultFileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'nama_file' => ['required', 'string', 'max:255'],
            'jenis_file' => ['required', 'string', 'max:255'],
            'file' => ['required', 'file', 'max:5120', 'mimes:application/pdf,image/jpeg,image/png'],
        ];
    }
}
