<?php

namespace App\Http\Requests\Verifikator;

use Illuminate\Foundation\Http\FormRequest;

class UpdateStatusRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $statuses = [
            'DIVERIFIKASI',
            'PERLU_PERBAIKAN',
            'MENUNGGU_PEMBAYARAN',
            'DIPROSES',
            'SELESAI',
            'DITOLAK',
        ];

        return [
            'status' => ['required', 'string', 'max:40', 'in:' . implode(',', $statuses)],
            'catatan' => ['nullable', 'string'],
        ];
    }
}
