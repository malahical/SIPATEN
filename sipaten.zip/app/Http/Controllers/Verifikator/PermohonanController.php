<?php

namespace App\Http\Controllers\Verifikator;

use App\Http\Controllers\Controller;
use App\Http\Requests\Verifikator\StoreResultFileRequest;
use App\Http\Requests\Verifikator\UpsertBillingRequest;
use App\Http\Requests\Verifikator\UpdateStatusRequest;
use App\Models\Billings;
use App\Models\Permohonan;
use App\Models\PermohonanFile;
use App\Models\StatusLog;
use App\Models\NotificationLog;
use App\Services\FonnteService;
use App\Services\GoogleDriveService;
use Illuminate\Http\Request;

class PermohonanController extends Controller
{
    private const STATUS_OPTIONS = [
        'DIVERIFIKASI',
        'PERLU_PERBAIKAN',
        'MENUNGGU_PEMBAYARAN',
        'DIPROSES',
        'SELESAI',
        'DITOLAK',
    ];

    private const STATUS_TRANSITIONS = [
        // DRAFT masuk DIKIRIM/??? di sistem, namun UI update status tidak menampilkan DIKIRIM.
        // Karena itu transisi yang kami izinkan mulai dari status yang ada di UI.
        // Aturan disiplin: SELESAI tidak boleh dilompati sebelum DIPROSES.
        'DIVERIFIKASI' => ['PERLU_PERBAIKAN', 'MENUNGGU_PEMBAYARAN', 'DIPROSES', 'DITOLAK'],
        'PERLU_PERBAIKAN' => ['MENUNGGU_PEMBAYARAN', 'DIVERIFIKASI', 'DITOLAK'],
        'MENUNGGU_PEMBAYARAN' => ['DIPROSES', 'DITOLAK', 'PERLU_PERBAIKAN'],
        'DIPROSES' => ['SELESAI', 'DITOLAK', 'PERLU_PERBAIKAN'],
        // terminal states
        'SELESAI' => [],
        'DITOLAK' => [],
    ];

    private function queryPermohonanDinas(Request $request)
    {
        $user = $request->user();

        return Permohonan::whereHas('operator', function ($qq) use ($user) {
            $qq->where('dinas_id', $user->dinas_id);
        });
    }

    private function queryPermohonanDinasByStatus(Request $request, string $status)
    {
        return $this->queryPermohonanDinas($request)->where('status', $status);
    }

    private function queryPermohonanDinasByBillingBelumLunas(Request $request)
    {
        // Phase 3: minimal billing flow -> tampilkan permohonan yang sudah punya billing (created) dan menunggu pembayaran
        return $this->queryPermohonanDinas($request)
            ->whereHas('billings')
            ->where('status', 'MENUNGGU_PEMBAYARAN');
    }

    private function queryPermohonanDinasSelesai(Request $request)
    {
        return $this->queryPermohonanDinasByStatus($request, 'SELESAI');
    }

    private function queryPermohonanDinasArsip(Request $request)
    {
        return $this->queryPermohonanDinas($request)
            ->whereIn('status', ['SELESAI', 'DITOLAK']);
    }

    public function dashboard(Request $request)
    {
        $q = $this->queryPermohonanDinas($request);

        $todayCount = (clone $q)->whereDate('created_at', today())->count();

        $dikirm = (clone $q)->where('status', 'DIKIRIM')->count();
        $perluPerbaikan = (clone $q)->where('status', 'PERLU_PERBAIKAN')->count();
        $selesai = (clone $q)->where('status', 'SELESAI')->count();

        return view('verifikator.dashboard', [
            'todayCount' => $todayCount,
            'dikirm' => $dikirm,
            'perluPerbaikan' => $perluPerbaikan,
            'selesai' => $selesai,
        ]);
    }

    public function index(Request $request)
    {
        $permohonans = $this->queryPermohonanDinas($request)
            ->with(['layanan', 'kecamatan', 'operator'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('verifikator.permohonans.index', [
            'permohonans' => $permohonans,
        ]);
    }

    public function perluPerbaikan(Request $request)
    {
        $permohonans = $this->queryPermohonanDinasByStatus($request, 'PERLU_PERBAIKAN')
            ->with(['layanan', 'kecamatan', 'operator'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('verifikator.permohonans.index', [
            'permohonans' => $permohonans,
            'activeCategory' => 'perlu-perbaikan',
        ]);
    }

    public function billing(Request $request)
    {
        $permohonans = $this->queryPermohonanDinasByBillingBelumLunas($request)
            ->with(['layanan', 'kecamatan', 'operator'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('verifikator.permohonans.index', [
            'permohonans' => $permohonans,
            'activeCategory' => 'billing',
        ]);
    }

    public function dokumenSelesai(Request $request)
    {
        $permohonans = $this->queryPermohonanDinasSelesai($request)
            ->with(['layanan', 'kecamatan', 'operator', 'files.uploader'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('verifikator.permohonans.index', [
            'permohonans' => $permohonans,
            'activeCategory' => 'dokumen-selesai',
        ]);
    }

    public function arsip(Request $request)
    {
        $permohonans = $this->queryPermohonanDinasArsip($request)
            ->with(['layanan', 'kecamatan', 'operator'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('verifikator.permohonans.index', [
            'permohonans' => $permohonans,
            'activeCategory' => 'arsip',
        ]);
    }

    public function show(Request $request, Permohonan $permohonan)
    {
        $user = $request->user();

        // pastikan permohonan hanya milik dinas user
        $owns = $permohonan->operator
            && (string) $permohonan->operator->dinas_id === (string) $user->dinas_id;

        abort_unless($owns, 403);

        $permohonan->load([
            'layanan',
            'kecamatan',
            'operator',
            'files.uploader',
            'statusLogs',
            'billings',
        ]);

        $latestStatus = optional($permohonan->statusLogs->sortByDesc('created_at')->first())->status;

        return view('verifikator.permohonans.show', [
            'permohonan' => $permohonan,
            'latestStatus' => $latestStatus,
        ]);
    }

    private function normalizeJenisLayanan(?string $jenisLayanan): string
    {
        return strtolower(trim($jenisLayanan ?? ''));
    }

    private function requiresBilling(Permohonan $permohonan): bool
    {
        // Rule gating hanya berlaku untuk layanan yang membutuhkan pembayaran
        // Sesuai requirement: jenis_layanan = pajak_retribusi
        $jenis = $this->normalizeJenisLayanan(optional($permohonan->layanan)->jenis_layanan);

        return $jenis === 'pajak_retribusi';
    }

    private function canTransitionTo(string $current, string $next): bool
    {
        $allowedNext = self::STATUS_TRANSITIONS[$current] ?? [];

        return in_array($next, $allowedNext, true);
    }

    private function transitionRejectMessage(string $current, string $next): string
    {
        $allowedNext = self::STATUS_TRANSITIONS[$current] ?? [];
        $allowedList = implode(', ', $allowedNext);

        return "Transisi status ditolak. Status saat ini '{$current}' tidak boleh berubah ke '{$next}'. Allowed next: {$allowedList}.";
    }

    private function hasBilling(Permohonan $permohonan): bool
    {
        return $permohonan->billings()->exists();
    }

    private function hasBillingNotBelumBayar(Permohonan $permohonan): bool
    {
        // Hanya cek billing status_bayar (karena saat ini UI belum menyediakan endpoint untuk status_bayar selain yang akan kita tambahkan)
        return $permohonan->billings()
            ->where('status_bayar', '!=', 'BELUM_BAYAR')
            ->exists();
    }

    // Backward compatible alias (used by tests/routes expecting updateStatusBayar)
    public function updateStatusBayar(Request $request, Permohonan $permohonan)
    {
        return $this->updateBillingStatusBayar($request, $permohonan);
    }

    public function updateBillingStatusBayar(Request $request, Permohonan $permohonan)
    {
        $user = $request->user();

        $owns = $permohonan->operator
            && (string) $permohonan->operator->dinas_id === (string) $user->dinas_id;

        abort_unless($owns, 403);

        $allowedStatusBayar = ['BELUM_BAYAR', 'LUNAS', 'KADALUARSA', 'DIBATALKAN'];
        $statusBayar = $request->input('status_bayar');

        if (!is_string($statusBayar) || !in_array($statusBayar, $allowedStatusBayar, true)) {
            return response()->json([
                'message' => 'status_bayar tidak valid.',
            ], 422);
        }

        $permohonan->loadMissing(['operator', 'billings']);

        $billing = $permohonan->billings()->latest()->first();
        abort_unless($billing, 404, 'Billing tidak ditemukan.');

        $billing->status_bayar = $statusBayar;
        $billing->save();

        // Catat perubahan status billing agar audit jelas.
        NotificationLog::create([
            'permohonan_id' => $permohonan->id,
            'event' => 'billing_status_bayar_berubah',
            'to_number' => (string) $permohonan->no_wa_pemohon,
            'message' => "Status billing {$permohonan->nomor_registrasi} diperbarui menjadi: {$statusBayar}.",
            'status' => 'sent',
            'response_status' => null,
            'response_body' => null,
            'sent_at' => null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('verifikator.permohonans.show', $permohonan)
            ->with('success', 'Status billing berhasil diperbarui.');
    }

    public function updateStatus(UpdateStatusRequest $request, Permohonan $permohonan)
    {
        $user = $request->user();

        $owns = $permohonan->operator
            && (string) $permohonan->operator->dinas_id === (string) $user->dinas_id;

        abort_unless($owns, 403);

        $validated = $request->validated();
        $nextStatus = $validated['status'];

        // Pastikan relasi untuk gating billing tersedia
        $permohonan->loadMissing(['layanan', 'billings', 'operator']);

        $currentStatus = (string) $permohonan->status;

        if ($currentStatus === $nextStatus) {
            return redirect()
                ->route('verifikator.permohonans.show', $permohonan)
                ->with('error', "Status permohonan sudah '{$nextStatus}'. Tidak ada perubahan yang dilakukan.");
        }

        // 1) Validasi transisi status (mapping terpusat)
        abort_unless(
            $this->canTransitionTo($currentStatus, $nextStatus),
            422,
            $this->transitionRejectMessage($currentStatus, $nextStatus)
        );

        $needsBilling = $this->requiresBilling($permohonan);

        // 2) Validasi billing hanya untuk layanan yang butuh billing
        if ($nextStatus === 'MENUNGGU_PEMBAYARAN') {
            // MENUNGGU_PEMBAYARAN wajib billing minimal 1 hanya jika butuh billing
            if ($needsBilling) {
                abort_unless($this->hasBilling($permohonan), 422, 'MENUNGGU_PEMBAYARAN membutuhkan minimal 1 billing.');
            }
        }

        // Rule final: status DIPROSES/SELESAI tidak dikunci berdasarkan status_bayar.
        // Billing hanya berperan sebagai informasi untuk monitoring pajak/retribusi.
        // Untuk non-pajak: tidak perlu billing sama sekali.

        // 3) Simpan ke status_logs + update status
        StatusLog::create([
            'permohonan_id' => $permohonan->id,
            'status' => $nextStatus,
            'changed_by' => $user->id,
            'catatan' => $validated['catatan'] ?? null,
        ]);

        $permohonan->status = $nextStatus;
        $permohonan->catatan_terakhir = $validated['catatan'] ?? null;
        $permohonan->save();

        // Phase 4: Notifikasi WhatsApp - status berubah
        $noWa = $permohonan->no_wa_pemohon;
        $fonnte = app(FonnteService::class);

        $message = "Status permohonan {$permohonan->nomor_registrasi} diperbarui menjadi: {$nextStatus}.";
        $result = $fonnte->sendWA($noWa, $message);

        NotificationLog::create([
            'permohonan_id' => $permohonan->id,
            'event' => 'status_berubah',
            'to_number' => (string) $noWa,
            'message' => $message,
            'status' => $result['success'] ? 'sent' : 'failed',
            'response_status' => $result['response_status'],
            'response_body' => $result['response_body'],
            'sent_at' => $result['success'] ? now() : null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('verifikator.permohonans.show', $permohonan)
            ->with('success', 'Status berhasil diperbarui.');
    }

    public function upsertBilling(UpsertBillingRequest $request, Permohonan $permohonan)
    {
        $user = $request->user();

        $owns = $permohonan->operator
            && (string) $permohonan->operator->dinas_id === (string) $user->dinas_id;

        abort_unless($owns, 403);

        $validated = $request->validated();

        $billing = $permohonan->billings()->firstOrNew([]);

        $billing->fill([
            'nomor_billing' => $validated['nomor_billing'] ?? null,
            'jenis_billing' => $validated['jenis_billing'] ?? null,
            'nominal' => $validated['nominal'] ?? null,
            'tanggal_billing' => $validated['tanggal_billing'] ?? null,
            'batas_bayar' => $validated['batas_bayar'] ?? null,
            'catatan' => $validated['catatan'] ?? null,
            'created_by' => $billing->exists ? $billing->created_by : $user->id,
        ]);

        $billing->permohonan_id = $permohonan->id;
        $billing->save();

        // Phase 4: Notifikasi WhatsApp - billing tersedia (minimal trigger saat billing disimpan)
        $noWa = $permohonan->no_wa_pemohon;
        $fonnte = app(FonnteService::class);

        $nomorBilling = $billing->nomor_billing ?? '-';
        $message = "Billing untuk permohonan {$permohonan->nomor_registrasi} tersedia. No. Billing: {$nomorBilling}.";
        $result = $fonnte->sendWA($noWa, $message);

        NotificationLog::create([
            'permohonan_id' => $permohonan->id,
            'event' => 'billing_tersedia',
            'to_number' => (string) $noWa,
            'message' => $message,
            'status' => $result['success'] ? 'sent' : 'failed',
            'response_status' => $result['response_status'],
            'response_body' => $result['response_body'],
            'sent_at' => $result['success'] ? now() : null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('verifikator.permohonans.show', $permohonan)
            ->with('success', 'Billing berhasil disimpan.');
    }

    public function storeResultFile(
        StoreResultFileRequest $request,
        Permohonan $permohonan,
        GoogleDriveService $googleDrive
    ) {
        $user = $request->user();

        $owns = $permohonan->operator
            && (string) $permohonan->operator->dinas_id === (string) $user->dinas_id;

        abort_unless($owns, 403);

        $validated = $request->validated();

        // Struktur folder:
        // SIPATEN/
        //   Tahun/
        //     Kecamatan/
        //       Nomor Registrasi/
        $tahun = (string) now()->format('Y');
        $kecamatanNama = optional($permohonan->kecamatan)->nama_kecamatan;

        $kecamatanNama = is_string($kecamatanNama) && trim($kecamatanNama) !== '' ? $kecamatanNama : 'UnknownKecamatan';
        $nomorRegistrasi = is_string($permohonan->nomor_registrasi) ? $permohonan->nomor_registrasi : ('PERMOHONAN-' . $permohonan->id);

        $folderParts = ['SIPATEN', $tahun, $kecamatanNama, $nomorRegistrasi];

        $uploadedFile = $request->file('file');
        $driveMeta = null;

        if ($uploadedFile) {
            $driveMeta = $googleDrive->uploadFile($uploadedFile, $folderParts);
        }

        $driveFileId = $driveMeta['drive_file_id'] ?? null;
        $driveUrl = $driveMeta['drive_url'] ?? null;

        PermohonanFile::create([
            'permohonan_id' => $permohonan->id,
            'nama_file' => $validated['nama_file'],
            'jenis_file' => $validated['jenis_file'],
            'drive_file_id' => $driveFileId,
            'drive_url' => $driveUrl,
            'uploaded_by' => $user->id,
        ]);

        // Phase 4: Notifikasi WhatsApp - dokumen selesai
        $noWa = $permohonan->no_wa_pemohon;
        $fonnte = app(FonnteService::class);

        $message = "Dokumen permohonan {$permohonan->nomor_registrasi} telah selesai dan siap diunduh.";
        $result = $fonnte->sendWA($noWa, $message);

        NotificationLog::create([
            'permohonan_id' => $permohonan->id,
            'event' => 'dokumen_selesai',
            'to_number' => (string) $noWa,
            'message' => $message,
            'status' => $result['success'] ? 'sent' : 'failed',
            'response_status' => $result['response_status'],
            'response_body' => $result['response_body'],
            'sent_at' => $result['success'] ? now() : null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('verifikator.permohonans.show', $permohonan)
            ->with('success', 'Dokumen hasil berhasil dicatat.');
    }
}
