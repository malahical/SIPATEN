<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __invoke(Request $request)
    {
        $role = (string) optional($request->user())->role;

        return match ($role) {
            'operator' => view('dashboard.operator'),
            'verifikator' => view('dashboard.verifikator'),
            'admin' => $this->adminDashboard($request),
            default => redirect()->route('profile.edit'),
        };
    }

    private function adminDashboard(Request $request)
    {
        $user = $request->user();

        $slaDays = 3;

        $filters = [
            'kecamatan_id' => $request->query('kecamatan_id'),
            'dinas_id' => $request->query('dinas_id'),
            'layanan_id' => $request->query('layanan_id'),
            'status' => $request->query('status'),
        ];

        $baseQuery = \App\Models\Permohonan::query()
            ->with(['layanan', 'kecamatan', 'operator'])
            ->when(!empty($filters['kecamatan_id']), fn($q) => $q->where('kecamatan_id', $filters['kecamatan_id']))
            ->when(!empty($filters['layanan_id']), fn($q) => $q->where('layanan_id', $filters['layanan_id']))
            ->when(!empty($filters['status']), fn($q) => $q->where('status', $filters['status']))
            ->when(!empty($filters['dinas_id']), function ($q) use ($filters) {
                $q->whereHas('operator', fn($qq) => $qq->where('dinas_id', $filters['dinas_id']));
            });

        $permohonanQuery = clone $baseQuery;

        // Note: MENUNGGU_PEMBAYARAN dikeluarkan karena skema saat ini tidak mengambil cash.
        $statusCounts = [
            'DIKIRIM' => (clone $baseQuery)->where('status', 'DIKIRIM')->count(),
            'PERLU_PERBAIKAN' => (clone $baseQuery)->where('status', 'PERLU_PERBAIKAN')->count(),
            'DIPROSES' => (clone $baseQuery)->where('status', 'DIPROSES')->count(),
            'SELESAI' => (clone $baseQuery)->where('status', 'SELESAI')->count(),
            'DITOLAK' => (clone $baseQuery)->where('status', 'DITOLAK')->count(),
        ];

        $totalCount = array_sum($statusCounts);

        $now = now();
        $slaThreshold = $now->copy()->subDays($slaDays);

        $slaOver = (clone $baseQuery)
            ->whereNotIn('status', ['SELESAI', 'DITOLAK', 'MENUNGGU_PEMBAYARAN'])
            ->where('created_at', '<', $slaThreshold)
            ->count();

        // Chart: layanan per bulan (ambil 6 bulan terakhir)
        $months = collect(range(0, 5))
            ->map(fn($i) => $now->copy()->subMonths($i)->format('Y-m'))
            ->reverse()
            ->values();

        $layananPerMonth = [];
        foreach ($months as $ym) {
            $layananPerMonth[$ym] = \App\Models\Permohonan::query()
                ->where('created_at', '>=', \Illuminate\Support\Carbon::parse($ym . '-01')->startOfMonth())
                ->where('created_at', '<', \Illuminate\Support\Carbon::parse($ym . '-01')->endOfMonth()->addSecond())
                ->selectRaw('layanan_id, COUNT(*) as cnt')
                ->groupBy('layanan_id')
                ->pluck('cnt', 'layanan_id');
        }

        // Grafik tambahan (Phase 5):
        // - Komposisi status (tanpa MENUNGGU_PEMBAYARAN)
        // - Permohonan per kecamatan
        // - Permohonan per dinas
        $statusComposition = $statusCounts;

        $kecamatanCounts = (clone $baseQuery)
            ->selectRaw('kecamatan_id, COUNT(*) as cnt')
            ->groupBy('kecamatan_id')
            ->orderByDesc('cnt')
            ->limit(10)
            ->get()
            ->mapWithKeys(fn($row) => [$row->kecamatan_id => (int)$row->cnt]);

        $dinasCounts = (clone $baseQuery)
            ->join('users as u', 'permohonans.operator_id', '=', 'u.id')
            ->selectRaw('u.dinas_id, COUNT(*) as cnt')
            ->groupBy('u.dinas_id')
            ->orderByDesc('cnt')
            ->limit(10)
            ->get()
            ->mapWithKeys(fn($row) => [$row->dinas_id => (int)$row->cnt]);

        // Data monitoring table (paginate)
        $permohonans = $permohonanQuery
            ->orderByDesc('created_at')
            ->paginate(10)
            ->withQueryString();

        // Lists for filter dropdown
        $kecamatans = \App\Models\Kecamatan::query()->orderBy('nama_kecamatan')->get();
        $dinasList = \App\Models\Dinas::query()->orderBy('nama_dinas')->get();
        $layananList = \App\Models\Layanan::query()->orderBy('nama_layanan')->get();

        return view('dashboard.admin', [
            'filters' => $filters,
            'statusCounts' => $statusCounts,
            'totalCount' => $totalCount,
            'slaOver' => $slaOver,
            'months' => $months,
            'layananPerMonth' => $layananPerMonth,
            'permohonans' => $permohonans,
            'kecamatans' => $kecamatans,
            'dinasList' => $dinasList,
            'layananList' => $layananList,
            'slaDays' => $slaDays,
        ]);
    }
}

