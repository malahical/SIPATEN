<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreKecamatanRequest;
use App\Http\Requests\Admin\UpdateKecamatanRequest;
use App\Models\Kecamatan;
use Illuminate\Http\Request;

class KecamatanController extends Controller
{
    public function index(Request $request)
    {
        $query = Kecamatan::query()->latest();

        if ($request->filled('search')) {
            $q = (string) $request->input('search');
            $query->where('nama_kecamatan', 'like', "%{$q}%");
        }

        $kecamatans = $query->paginate(10);

        return view('admin.kecamatans.index', compact('kecamatans'));
    }

    public function create()
    {
        return view('admin.kecamatans.form', ['kecamatan' => null]);
    }

    public function store(StoreKecamatanRequest $request)
    {
        Kecamatan::create($request->validated());

        return redirect()
            ->route('admin.kecamatans.index')
            ->with('success', 'Kecamatan berhasil dibuat.');
    }

    public function edit(Kecamatan $kecamatan)
    {
        return view('admin.kecamatans.form', compact('kecamatan'));
    }

    public function update(UpdateKecamatanRequest $request, Kecamatan $kecamatan)
    {
        $kecamatan->update($request->validated());

        return redirect()
            ->route('admin.kecamatans.index')
            ->with('success', 'Kecamatan berhasil diperbarui.');
    }

    public function destroy(Kecamatan $kecamatan)
    {
        $kecamatan->delete();

        return redirect()
            ->route('admin.kecamatans.index')
            ->with('success', 'Kecamatan berhasil dihapus.');
    }
}
