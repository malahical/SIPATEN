<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreDinasRequest;
use App\Http\Requests\Admin\UpdateDinasRequest;
use App\Models\Dinas;
use Illuminate\Http\Request;

class DinasController extends Controller
{
    public function index(Request $request)
    {
        $query = Dinas::query()->latest();

        if ($request->filled('search')) {
            $q = (string) $request->input('search');
            $query->where('nama_dinas', 'like', "%{$q}%");
        }

        $dinases = $query->paginate(10);

        return view('admin.dinas.index', compact('dinases'));
    }

    public function create()
    {
        return view('admin.dinas.form', ['dinas' => null]);
    }

    public function store(StoreDinasRequest $request)
    {
        Dinas::create($request->validated());

        return redirect()
            ->route('admin.dinas.index')
            ->with('success', 'Dinas berhasil dibuat.');
    }

    public function edit(Dinas $dinas)
    {
        return view('admin.dinas.form', compact('dinas'));
    }

    public function update(UpdateDinasRequest $request, Dinas $dinas)
    {
        $dinas->update($request->validated());

        return redirect()
            ->route('admin.dinas.index')
            ->with('success', 'Dinas berhasil diperbarui.');
    }

    public function destroy(Dinas $dinas)
    {
        $dinas->delete();

        return redirect()
            ->route('admin.dinas.index')
            ->with('success', 'Dinas berhasil dihapus.');
    }
}
