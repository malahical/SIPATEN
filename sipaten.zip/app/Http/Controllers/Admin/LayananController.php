<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreLayananRequest;
use App\Http\Requests\Admin\UpdateLayananRequest;
use App\Models\Layanan;
use Illuminate\Http\Request;

class LayananController extends Controller
{
    public function index(Request $request)
    {
        $query = Layanan::query()->with('dinas')->latest();

        if ($request->filled('search')) {
            $q = (string) $request->input('search');
            $query->where('nama_layanan', 'like', "%{$q}%");
        }

        $layanans = $query->paginate(10);

        return view('admin.layanans.index', compact('layanans'));
    }

    public function create()
    {
        return view('admin.layanans.form', ['layanan' => null]);
    }

    public function store(StoreLayananRequest $request)
    {
        Layanan::create($request->validated());

        return redirect()
            ->route('admin.layanans.index')
            ->with('success', 'Layanan berhasil dibuat.');
    }

    public function edit(Layanan $layanan)
    {
        return view('admin.layanans.form', compact('layanan'));
    }

    public function update(UpdateLayananRequest $request, Layanan $layanan)
    {
        $layanan->update($request->validated());

        return redirect()
            ->route('admin.layanans.index')
            ->with('success', 'Layanan berhasil diperbarui.');
    }

    public function destroy(Layanan $layanan)
    {
        $layanan->delete();

        return redirect()
            ->route('admin.layanans.index')
            ->with('success', 'Layanan berhasil dihapus.');
    }
}
