<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use App\Models\Kecamatan;
use App\Models\Layanan;
use App\Models\Permohonan;
use App\Models\PermohonanFile;
use App\Models\StatusLog;
use App\Models\NotificationLog;
use App\Services\FonnteService;
use App\Services\GoogleDriveService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PermohonanController extends Controller
{
    public function __construct(private GoogleDriveService $googleDriveService)
    {
    }

    public function create()
    {
        $layananList = Layanan::query()->where('is_active', 1)->get();
        $kecamatan = Kecamatan::query()
            ->where('id', Auth::user()->kecamatan_id)
            ->first();

        return view('operator.permohonans.create', [
            'layananList' => $layananList,
            'kecamatan' => $kecamatan,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'layanan_id' => ['required', 'exists:layanans,id'],
            'nama_pemohon' => ['required', 'string', 'max:255'],
            'nik' => ['required', 'string', 'max:50'],
            'alamat' => ['required', 'string'],
            'no_wa_pemohon' => ['nullable', 'string', 'max:30'],
            'catatan_terakhir' => ['nullable', 'string'],
            'file' => ['required', 'array', 'min:1'],
            'file.*' => ['required', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
            'nama_file' => ['nullable', 'array'],
        ]);

        $user = Auth::user();

        $nomorRegistrasi = $this->generateNomorRegistrasi();

        $permohonan = Permohonan::create([
            'nomor_registrasi' => $nomorRegistrasi,
            'layanan_id' => $request->input('layanan_id'),
            'kecamatan_id' => $user->kecamatan_id,
            'operator_id' => $user->id,
            'nama_pemohon' => $request->input('nama_pemohon'),
            'nik' => $request->input('nik'),
            'alamat' => $request->input('alamat'),
            'no_wa_pemohon' => $request->input('no_wa_pemohon'),
            'status' => 'DRAFT',
            'catatan_terakhir' => $request->input('catatan_terakhir'),
        ]);

        // Upload dokumen ke Google Drive via GAS (jika GAS_UPLOAD_URL tersedia)
        $files = (array) $request->file('file', []);
        $namaFiles = (array) $request->input('nama_file', []);

        // Struktur folder (samakan dengan yang dipakai verifikator):
        // SIPATEN/<Tahun>/<Kecamatan>/<NomorRegistrasi>/
        $tahun = (string) now()->format('Y');
        $kecamatanNama = optional($permohonan->kecamatan)->nama_kecamatan;

        $kecamatanNama = is_string($kecamatanNama) && trim($kecamatanNama) !== ''
            ? $kecamatanNama
            : 'UnknownKecamatan';

        $nomorRegistrasi = is_string($permohonan->nomor_registrasi)
            ? $permohonan->nomor_registrasi
            : ('PERMOHONAN-' . $permohonan->id);

        $folderParts = ['SIPATEN', $tahun, $kecamatanNama, $nomorRegistrasi];

        foreach ($files as $idx => $uploaded) {
            $originalName = $uploaded->getClientOriginalName();
            $fileName = $namaFiles[$idx] ?? $originalName;

            $driveMeta = $this->googleDriveService->uploadFile($uploaded, $folderParts);

            $PermohonanFile = new PermohonanFile();
            $PermohonanFile->fill([
                'permohonan_id' => $permohonan->id,
                'nama_file' => $fileName,
                'jenis_file' => $uploaded->getClientOriginalExtension(),
                'drive_file_id' => $driveMeta['drive_file_id'] ?? null,
                'drive_url' => $driveMeta['drive_url'] ?? null,
                'uploaded_by' => $user->id,
            ]);
            $PermohonanFile->save();
        }

        // Simpan status_logs awal
        StatusLog::create([
            'permohonan_id' => $permohonan->id,
            'changed_by' => $user->id,
            'catatan' => 'Permohonan dibuat (DRAFT).',
        ]);

        // Phase 4: Notifikasi WhatsApp - permohonan dibuat/diterima operator
        $noWa = $permohonan->no_wa_pemohon;
        $fonnte = app(FonnteService::class);

        $message = "Halo, permohonan Anda telah diterima. Nomor registrasi: {$permohonan->nomor_registrasi}.";
        $result = $fonnte->sendWA($noWa, $message);

        NotificationLog::create([
            'permohonan_id' => $permohonan->id,
            'event' => 'permohonan_dikirim',
            'to_number' => (string) $noWa,
            'message' => $message,
            'status' => $result['success'] ? 'sent' : 'failed',
            'response_status' => $result['response_status'],
            'response_body' => $result['response_body'],
            'sent_at' => $result['success'] ? now() : null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('operator.permohonans.show', $permohonan)
            ->with('success', 'Permohonan berhasil dibuat.');
    }

    public function index()
    {
        $user = Auth::user();

        $permohonans = Permohonan::query()
            ->where('kecamatan_id', $user->kecamatan_id)
            ->latest()
            ->paginate(10);

        return view('operator.permohonans.index', compact('permohonans'));
    }

    public function show(Permohonan $permohonan)
    {
        $this->authorizeAccess($permohonan);

        $permohonan->load(['layanan', 'kecamatan', 'operator', 'files', 'statusLogs' => function ($q) {
            $q->latest('created_at');
        }]);

        return view('operator.permohonans.show', compact('permohonan'));
    }

    public function tracking(Permohonan $permohonan)
    {
        $this->authorizeAccess($permohonan);

        $permohonan->load([
            'layanan',
            'kecamatan',
            'statusLogs' => function ($q) {
                $q->orderBy('created_at');
            },
        ]);

        return view('operator.permohonans.tracking', compact('permohonan'));
    }

    public function receipt(Permohonan $permohonan)
    {
        $this->authorizeAccess($permohonan);

        $permohonan->load([
            'layanan',
            'kecamatan',
            'operator',
            'files',
            'statusLogs' => function ($q) {
                $q->orderBy('created_at');
            },
        ]);

        return view('operator.permohonans.receipt', compact('permohonan'));
    }

    private function authorizeAccess(Permohonan $permohonan): void
    {
        $user = Auth::user();

        abort_unless(
            $permohonan->kecamatan_id === $user->kecamatan_id,
            403
        );
    }

    private function generateNomorRegistrasi(): string
    {
        $today = now()->format('Ymd');
        $prefix = 'SIPATEN-' . $today . '-';

        $count = Permohonan::query()
            ->where('nomor_registrasi', 'like', $prefix . '%')
            ->count();

        $seq = str_pad((string) ($count + 1), 4, '0', STR_PAD_LEFT);

        return $prefix . $seq;
    }
}
