<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        $user = Auth::user();
        if (!$user) {
            abort(403);
        }

        $currentRole = (string) $user->role;
        $allowed = array_map(fn ($r) => (string) $r, $roles);

        if (!in_array($currentRole, $allowed, true)) {
            abort(403);
        }

        return $next($request);
    }
}

