@props(['title' => null])

<x-app-layout>
    {{-- Override layout sederhana: gunakan wrapper baru dengan sidebar/topbar --}}
    @php
        $content = $slot;
    @endphp

    <x-slot name="header">
        <div class="font-semibold text-xl text-gray-800">{{ $title ?? '' }}</div>
    </x-slot>

    <div class="min-h-screen bg-[#FDFDFC]">
        @include('layouts.sidebar')
        <div class="md:ml-72">
            @include('layouts.topbar')
            <main class="p-4 md:p-6">{{ $content }}</main>
        </div>
    </div>
</x-app-layout>

