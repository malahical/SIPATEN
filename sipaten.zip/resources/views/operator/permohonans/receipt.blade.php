@extends('layouts.sipaten-app')

@section('content')
    <div class="max-w-4xl mx-auto p-4 sm:p-6">
        <div class="mb-4 flex items-center justify-between gap-3">
            <div>
                <h1 class="text-2xl font-semibold text-slate-800">Tanda Terima Permohonan</h1>
                <p class="text-slate-600 mt-1 text-sm">
                    Nomor registrasi: <span class="font-medium text-slate-800">{{ $permohonan->nomor_registrasi }}</span>
                </p>
            </div>

            <div class="flex gap-2 print:hidden">
                <a href="{{ route('operator.permohonans.show', $permohonan) }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Kembali
                </a>

                <button type="button"
                        onclick="window.print()"
                        class="px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                    Cetak / Save PDF
                </button>
            </div>
        </div>

        <div id="receipt-card"
             class="bg-white shadow-sm rounded-xl border border-slate-100 p-6 print:p-0 print:border-0">
            <div class="text-center">
                <div class="text-xs text-slate-500">SIPATEN</div>
                <div class="text-base sm:text-lg font-bold text-slate-900">
                    Sistem Pelayanan Kecamatan Terpadu
                </div>
                <div class="text-xs sm:text-sm text-slate-600 mt-1">
                    TANDA TERIMA PERMOHONAN
                </div>
            </div>

            <hr class="my-4 border-slate-200"/>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                    <div class="text-slate-500">Nomor Registrasi</div>
                    <div class="font-semibold text-slate-900">{{ $permohonan->nomor_registrasi }}</div>
                </div>

                <div>
                    <div class="text-slate-500">Tanggal</div>
                    <div class="font-semibold text-slate-900">
                        {{ optional($permohonan->created_at)->format('d M Y') }}
                    </div>
                </div>

                <div>
                    <div class="text-slate-500">Layanan</div>
                    <div class="font-semibold text-slate-900">
                        {{ $permohonan->layanan?->nama_layanan ?? '-' }}
                    </div>
                </div>

                <div>
                    <div class="text-slate-500">Kecamatan</div>
                    <div class="font-semibold text-slate-900">
                        {{ $permohonan->kecamatan?->nama_kecamatan ?? '-' }}
                    </div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-slate-500">Nama Pemohon</div>
                    <div class="font-semibold text-slate-900">{{ $permohonan->nama_pemohon }}</div>
                </div>

                <div>
                    <div class="text-slate-500">NIK</div>
                    <div class="font-semibold text-slate-900">{{ $permohonan->nik }}</div>
                </div>

                <div>
                    <div class="text-slate-500">WhatsApp</div>
                    <div class="font-semibold text-slate-900">{{ $permohonan->no_wa_pemohon ?? '-' }}</div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-slate-500">Alamat</div>
                    <div class="font-semibold text-slate-900">{{ $permohonan->alamat }}</div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-slate-500 mb-2">Berkas yang diunggah</div>
                    @if($permohonan->files->count() > 0)
                        <ul class="list-disc pl-5 space-y-1">
                            @foreach($permohonan->files as $file)
                                <li class="text-slate-900">{{ $file->nama_file }}</li>
                            @endforeach
                        </ul>
                    @else
                        <div class="text-slate-900">-</div>
                    @endif
                </div>
            </div>

            <div class="mt-6 text-sm text-slate-600">
                Status saat ini: <span class="font-semibold text-slate-900">{{ $permohonan->status }}</span>
            </div>

            <div class="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="sm:col-span-2"></div>
                <div class="text-center">
                    <div class="text-xs text-slate-500">Operator</div>
                    <div class="mt-2 font-semibold text-slate-900">
                        {{ $permohonan->operator?->name ?? '-' }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        @media print {
            body {
                background: white !important;
            }
            .print:hidden {
                display: none !important;
            }
            #receipt-card {
                border: 0 !important;
                box-shadow: none !important;
                padding: 0 !important;
            }
        }
    </style>
@endsection
