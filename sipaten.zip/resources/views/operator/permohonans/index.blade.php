@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-5xl mx-auto p-4 sm:p-6">
    <div class="flex items-center justify-between mb-4">
        <div>
            <h1 class="text-2xl font-semibold text-slate-800">Berkas Saya</h1>
            <p class="text-slate-600 mt-1 text-sm">Daftar permohonan yang Anda ajukan.</p>
        </div>

        <a href="{{ route('operator.permohonans.create') }}" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
            + Pengajuan Baru
        </a>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 overflow-hidden">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-50 text-slate-700">
                <tr>
                    <th class="text-left font-medium px-4 py-3">Nomor</th>
                    <th class="text-left font-medium px-4 py-3">Layanan</th>
                    <th class="text-left font-medium px-4 py-3">Status</th>
                    <th class="text-left font-medium px-4 py-3">Terakhir</th>
                    <th class="text-left font-medium px-4 py-3">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse ($permohonans as $permohonan)
                    <tr class="hover:bg-slate-50/70">
                        <td class="px-4 py-3 font-medium text-slate-900">{{ $permohonan->nomor_registrasi }}</td>
                        <td class="px-4 py-3 text-slate-700">{{ $permohonan->layanan?->nama_layanan ?? '-' }}</td>
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold
                                {{ match($permohonan->status) {
                                    'DRAFT' => 'bg-slate-100 text-slate-700',
                                    'DIKIRIM' => 'bg-blue-100 text-blue-700',
                                    'PERLU_PERBAIKAN' => 'bg-amber-100 text-amber-800',
                                    'MENUNGGU_PEMBAYARAN' => 'bg-purple-100 text-purple-800',
                                    'DIPROSES' => 'bg-indigo-100 text-indigo-800',
                                    'SELESAI' => 'bg-green-100 text-green-700',
                                    'DITOLAK' => 'bg-red-100 text-red-700',
                                    default => 'bg-slate-100 text-slate-700'
                                }}">
                                {{ $permohonan->status }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-slate-600">{{ optional($permohonan->updated_at)->format('d M Y') }}</td>
                        <td class="px-4 py-3">
                            <div class="flex gap-2">
                                <a href="{{ route('operator.permohonans.show', $permohonan) }}" class="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50">
                                    Detail
                                </a>
                                <a href="{{ route('operator.permohonans.tracking', $permohonan) }}" class="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                                    Tracking
                                </a>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-4 py-6 text-center text-slate-600">
                            Belum ada permohonan.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $permohonans->links() }}
    </div>
</div>
@endsection
