@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-3xl mx-auto p-4 sm:p-6">
    <div class="mb-5">
        <h1 class="text-2xl font-semibold text-slate-800">Pengajuan Baru</h1>
        <p class="text-slate-600 mt-1">Ajukan permohonan dengan langkah sederhana.</p>
    </div>

    @if ($errors->any())
        <div class="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-red-700">
            <div class="font-semibold mb-1">Periksa input berikut:</div>
            <ul class="list-disc ml-5">
                @foreach ($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        <form method="POST" action="{{ route('operator.permohonans.store') }}" enctype="multipart/form-data">
            @csrf

            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Layanan</label>
                    <select name="layanan_id"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                        required>
                        <option value="">-- Pilih Layanan --</option>
                        @foreach ($layananList as $layanan)
                            <option value="{{ $layanan->id }}" @selected(old('layanan_id') == $layanan->id)>
                                {{ $layanan->nama_layanan }}
                            </option>
                        @endforeach
                    </select>
                    @error('layanan_id')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Nama Pemohon</label>
                    <input type="text" name="nama_pemohon"
                        value="{{ old('nama_pemohon') }}"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                        required>
                    @error('nama_pemohon')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">NIK</label>
                        <input type="text" name="nik"
                            value="{{ old('nik') }}"
                            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            required>
                        @error('nik')
                            <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">No. WhatsApp (Opsional)</label>
                        <input type="text" name="no_wa_pemohon"
                            value="{{ old('no_wa_pemohon') }}"
                            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            maxlength="30">
                        @error('no_wa_pemohon')
                            <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Alamat</label>
                    <textarea name="alamat" rows="3"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                        required>{{ old('alamat') }}</textarea>
                    @error('alamat')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Catatan (Opsional)</label>
                    <textarea name="catatan_terakhir" rows="2"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200">{{ old('catatan_terakhir') }}</textarea>
                    @error('catatan_terakhir')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Upload Dokumen (PDF/JPG/PNG, maks 5MB per file)</label>
                    <input
                        type="file"
                        name="file[]"
                        multiple
                        accept=".pdf,.jpg,.jpeg,.png"
                        class="block w-full text-sm text-slate-600"
                        required>
                    @error('file')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                    @error('file.*')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="pt-2 flex gap-2">
                    <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                        Simpan Pengajuan
                    </button>
                    <a href="{{ route('operator.permohonans.index') }}"
                       class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                        Batal
                    </a>
                </div>
            </div>
        </form>

        <div class="mt-5 text-sm text-slate-500">
            Kecamatan: <span class="font-medium text-slate-700">{{ $kecamatan?->nama_kecamatan ?? '-' }}</span>
        </div>
    </div>
</div>
@endsection
