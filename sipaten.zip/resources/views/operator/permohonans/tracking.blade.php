@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-4xl mx-auto p-4 sm:p-6">
    <div class="mb-4">
        <div class="flex items-center justify-between gap-3">
            <div>
                <h1 class="text-2xl font-semibold text-slate-800">Tracking Status</h1>
                <p class="text-slate-600 mt-1 text-sm">
                    Nomor: <span class="font-medium text-slate-800">{{ $permohonan->nomor_registrasi }}</span>
                </p>
            </div>

            <div class="flex gap-2">
                <a href="{{ route('operator.permohonans.show', $permohonan) }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Detail
                </a>
                <a href="{{ route('operator.permohonans.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Kembali
                </a>
            </div>
        </div>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        <div class="flex items-center justify-between gap-3 mb-4">
            <div>
                <div class="text-xs font-medium text-slate-500">Status saat ini</div>
                <div class="text-lg font-semibold text-slate-800">{{ $permohonan->status }}</div>
            </div>
            <div class="text-sm text-slate-600">
                Layanan: <span class="font-medium text-slate-800">{{ $permohonan->layanan?->nama_layanan ?? '-' }}</span>
            </div>
        </div>

        <hr class="my-4 border-slate-100">

        <div class="text-sm font-semibold text-slate-800 mb-3">Riwayat Status</div>

        @if($permohonan->statusLogs->count() > 0)
            <div class="space-y-3">
                @foreach($permohonan->statusLogs as $log)
                    <div class="p-4 rounded-lg border border-slate-100 bg-slate-50">
                        <div class="flex items-center justify-between gap-2">
                            <div class="font-semibold text-slate-800">
                                {{ $log->catatan ?? 'Perubahan status' }}
                            </div>
                            <div class="text-xs text-slate-500">
                                {{ optional($log->created_at)->format('d M Y H:i') }}
                            </div>
                        </div>
                        <div class="text-xs text-slate-600 mt-1">
                            Oleh: {{ $log->changer?->name ?? '—' }}
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="text-slate-600">Belum ada riwayat status.</div>
        @endif
    </div>
</div>
@endsection
