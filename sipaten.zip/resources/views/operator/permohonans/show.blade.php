@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-4xl mx-auto p-4 sm:p-6">
    <div class="mb-4">
        <div class="flex items-center justify-between gap-3">
            <div>
                <h1 class="text-2xl font-semibold text-slate-800">Detail Permohonan</h1>
                <p class="text-slate-600 mt-1 text-sm">
                    Nomor registrasi: <span class="font-medium text-slate-800">{{ $permohonan->nomor_registrasi }}</span>
                </p>
            </div>

            <div class="flex gap-2">
                <a href="{{ route('operator.permohonans.receipt', $permohonan) }}"
                   class="px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                    Cetak Tanda Terima
                </a>

                <a href="{{ route('operator.permohonans.tracking', $permohonan) }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Tracking
                </a>

                <a href="{{ route('operator.permohonans.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Kembali
                </a>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 bg-white shadow-sm rounded-xl border border-slate-100 p-5">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <div class="text-xs font-medium text-slate-500">Layanan</div>
                    <div class="mt-1 font-semibold text-slate-800">{{ $permohonan->layanan?->nama_layanan ?? '-' }}</div>
                </div>

                <div>
                    <div class="text-xs font-medium text-slate-500">Kecamatan</div>
                    <div class="mt-1 font-semibold text-slate-800">{{ $permohonan->kecamatan?->nama_kecamatan ?? '-' }}</div>
                </div>

                <div>
                    <div class="text-xs font-medium text-slate-500">Nama Pemohon</div>
                    <div class="mt-1 text-slate-800">{{ $permohonan->nama_pemohon }}</div>
                </div>

                <div>
                    <div class="text-xs font-medium text-slate-500">NIK</div>
                    <div class="mt-1 text-slate-800">{{ $permohonan->nik }}</div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-xs font-medium text-slate-500">Alamat</div>
                    <div class="mt-1 text-slate-800">{{ $permohonan->alamat }}</div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-xs font-medium text-slate-500">WhatsApp</div>
                    <div class="mt-1 text-slate-800">{{ $permohonan->no_wa_pemohon ?? '-' }}</div>
                </div>

                <div class="sm:col-span-2">
                    <div class="text-xs font-medium text-slate-500">Catatan Terakhir</div>
                    <div class="mt-1 text-slate-800">{{ $permohonan->catatan_terakhir ?? '-' }}</div>
                </div>
            </div>

            <hr class="my-5 border-slate-100">

            <div>
                <div class="text-sm font-semibold text-slate-800 mb-2">Berkas yang diunggah</div>

                @if($permohonan->files->count() > 0)
                    <ul class="space-y-2">
                        @foreach($permohonan->files as $file)
                            <li class="flex items-center justify-between gap-3 p-3 rounded-lg bg-slate-50 border border-slate-100">
                                <div class="min-w-0">
                                    <div class="font-medium text-slate-800 truncate">{{ $file->nama_file }}</div>
                                    <div class="text-xs text-slate-500">
                                        {{ strtoupper($file->jenis_file) }}
                                        @if($file->drive_file_id)
                                            • {{ $file->drive_file_id }}
                                        @endif
                                    </div>
                                </div>

                                <div class="text-sm font-semibold text-slate-700">
                                    @if($file->drive_url)
                                        <a class="text-blue-600 hover:underline" href="{{ $file->drive_url }}" target="_blank" rel="noreferrer">Lihat</a>
                                    @else
                                        <span class="text-slate-400">Belum tersedia URL</span>
                                    @endif
                                </div>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <div class="text-slate-600">Belum ada berkas.</div>
                @endif
            </div>
        </div>

        <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
            <div class="text-sm font-semibold text-slate-800 mb-2">Status</div>
            <div class="mb-4">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold
                    {{ match($permohonan->status) {
                        'DRAFT' => 'bg-slate-100 text-slate-700',
                        'DIKIRIM' => 'bg-blue-100 text-blue-700',
                        'PERLU_PERBAIKAN' => 'bg-amber-100 text-amber-800',
                        'MENUNGGU_PEMBAYARAN' => 'bg-purple-100 text-purple-800',
                        'DIPROSES' => 'bg-indigo-100 text-indigo-800',
                        'SELESAI' => 'bg-green-100 text-green-700',
                        'DITOLAK' => 'bg-red-100 text-red-700',
                        default => 'bg-slate-100 text-slate-700'
                    } }}">
                    {{ $permohonan->status }}
                </span>
            </div>

            <div class="text-sm font-semibold text-slate-800 mb-2">Ringkasan</div>
            <div class="space-y-2 text-sm text-slate-700">
                <div class="flex justify-between gap-2">
                    <span class="text-slate-500">Dibuat</span>
                    <span class="font-medium">{{ optional($permohonan->created_at)->format('d M Y') }}</span>
                </div>
                <div class="flex justify-between gap-2">
                    <span class="text-slate-500">Update terakhir</span>
                    <span class="font-medium">{{ optional($permohonan->updated_at)->format('d M Y') }}</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
