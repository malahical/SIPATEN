<x-sipaten-base-layout>
    <x-slot:title>Dashboard Admin</x-slot:title>

    <div class="max-w-6xl mx-auto space-y-6">
        <div class="flex items-start justify-between gap-4">
            <div>
                <h1 class="text-2xl font-semibold">Dashboard Eksekutif</h1>
                <p class="text-sm text-gray-500 mt-1">
                    Monitoring permohonan, status, billing, dan highlight SLA (± {{ $slaDays }} hari).
                </p>
            </div>
        </div>

        {{-- Statistik card --}}
        <div class="grid grid-cols-1 md:grid-cols-6 gap-3">
            @php
                $total = max(1, (int)($totalCount ?? 0));
            @endphp

            @foreach([
                'DIKIRIM' => 'Dikirim',
                'PERLU_PERBAIKAN' => 'Perlu Perbaikan',
                'MENUNGGU_PEMBAYARAN' => 'Menunggu Pembayaran',
                'DIPROSES' => 'Diproses',
                'SELESAI' => 'Selesai',
                'DITOLAK' => 'Ditolak',
            ] as $key => $label)
                <div class="bg-white border rounded p-4 shadow-sm">
                    <div class="text-sm text-gray-500">{{ $label }}</div>
                    <div class="text-2xl font-bold text-blue-700">{{ $statusCounts[$key] ?? 0 }}</div>
                    <div class="mt-2">
                        @php
                            $cnt = (int)($statusCounts[$key] ?? 0);
                            $pct = round(($cnt / $total) * 100);
                        @endphp
                        <div class="h-2 bg-gray-100 rounded overflow-hidden">
                            <div class="h-2 bg-blue-600" style="width: {{ $pct }}%"></div>
                        </div>
                        <div class="text-xs text-gray-500 mt-1">{{ $pct }}%</div>
                    </div>
                </div>
            @endforeach
        </div>

        {{-- SLA highlight --}}
        <div class="bg-white border rounded p-4 shadow-sm">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <div class="text-sm text-gray-500">Highlight SLA lewat</div>
                    <div class="text-3xl font-bold text-red-600 mt-1">{{ $slaOver ?? 0 }}</div>
                </div>
                <div class="text-right">
                    <div class="text-xs text-gray-500">Kriteria: status bukan SELESAI/DITOLAK dan umur data > {{ $slaDays }} hari</div>
                </div>
            </div>
        </div>

        {{-- Grafik sederhana: layanan per bulan --}}
        <div class="bg-white border rounded p-4 shadow-sm">
            <h2 class="text-lg font-semibold mb-3">Grafik: Layanan per Bulan (6 bulan terakhir)</h2>

            @php
                // Flatten counts for rendering
                $allLayananIds = collect($layananList ?? collect())->pluck('id')->values()->all();
                $monthList = is_array($months ?? null) ? $months : [];
                // Build rows: layanan_id => [ym => cnt]
                $rows = [];
                foreach ($monthList as $ym) {
                    $counts = $layananPerMonth[$ym] ?? collect();
                    // $counts is collection (plucked cnt by layanan_id)
                    foreach ($counts as $layananId => $cnt) {
                        $rows[$layananId][$ym] = (int)$cnt;
                    }
                }
            @endphp

            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                        <tr class="text-left text-gray-600">
                            <th class="py-2 pr-4">Layanan</th>
                            @foreach($months as $ym)
                                <th class="py-2 pr-4">{{ $ym }}</th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse(($layananList ?? collect()) as $lay)
                            <tr>
                                <td class="py-2 pr-4 font-medium">{{ $lay->nama_layanan }}</td>
                                @foreach($months as $ym)
                                    @php
                                        $cnt = (int)($rows[$lay->id][$ym] ?? 0);
                                        $maxCntThisMonth = (int)($layananPerMonth[$ym] ?? collect())->max() ?: 1;
                                        $pctThisMonth = (int)round(($cnt / max(1, $maxCntThisMonth)) * 100);
                                    @endphp
                                    <td class="py-2 pr-4">
                                        <div class="h-3 bg-gray-100 rounded overflow-hidden">
                                            <div class="h-3 bg-blue-600" style="width: {{ max(0, min(100, $pctThisMonth)) }}%"></div>
                                        </div>
                                        <div class="text-xs text-gray-500 mt-1">{{ $cnt }}</div>
                                    </td>
                                @endforeach
                            </tr>
                        @empty
                            <tr>
                                <td colspan="{{ 2 + count($months) }}" class="py-4 text-gray-500">Belum ada data layanan.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Komposisi status + permohonan per kecamatan/dinas --}}
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-3">
            {{-- Komposisi status --}}
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Komposisi Status</h2>
                @php
                    $compTotal = max(1, (int) array_sum($statusComposition ?? []));
                @endphp
                <div class="space-y-3">
                    @php
                        $compItems = [
                            'DIKIRIM' => 'Dikirim',
                            'PERLU_PERBAIKAN' => 'Perlu Perbaikan',
                            'DIPROSES' => 'Diproses',
                            'SELESAI' => 'Selesai',
                            'DITOLAK' => 'Ditolak',
                        ];
                    @endphp
                    @foreach($compItems as $key => $label)
                        @php
                            $cnt = (int)($statusComposition[$key] ?? 0);
                            $pct = round(($cnt / $compTotal) * 100);
                        @endphp
                        <div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-700">{{ $label }}</span>
                                <span class="font-semibold text-gray-900">{{ $cnt }}</span>
                            </div>
                            <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                <div class="h-2 bg-blue-600" style="width: {{ $pct }}%"></div>
                            </div>
                            <div class="text-xs text-gray-500 mt-1">{{ $pct }}%</div>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- Permohonan per kecamatan --}}
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Permohonan per Kecamatan</h2>
                <div class="space-y-3">
                    @php
                        $kecItems = $kecamatanCounts ?? collect();
                    @endphp
                    @if(count($kecItems))
                        @foreach($kecItems as $kecamatanId => $cnt)
                            @php
                                $kecName = ($kecamatans->firstWhere('id', $kecamatanId)->nama_kecamatan) ?? '-';
                                $den = max(1, (int) array_sum($kecItems->toArray()));
                                $pct = round(((int)$cnt / $den) * 100);
                            @endphp
                            <div>
                                <div class="flex items-center justify-between text-sm">
                                    <span class="text-gray-700">{{ $kecName }}</span>
                                    <span class="font-semibold text-gray-900">{{ $cnt }}</span>
                                </div>
                                <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                    <div class="h-2 bg-green-600" style="width: {{ $pct }}%"></div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="text-sm text-gray-500">Belum ada data.</div>
                    @endif
                </div>
            </div>

            {{-- Permohonan per dinas --}}
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Permohonan per Dinas</h2>
                <div class="space-y-3">
                    @php
                        $dinasItems = $dinasCounts ?? collect();
                    @endphp
                    @if(count($dinasItems))
                        @foreach($dinasItems as $dinasId => $cnt)
                            @php
                                $dinasName = ($dinasList->firstWhere('id', $dinasId)->nama_dinas) ?? '-';
                                $den = max(1, (int) array_sum($dinasItems->toArray()));
                                $pct = round(((int)$cnt / $den) * 100);
                            @endphp
                            <div>
                                <div class="flex items-center justify-between text-sm">
                                    <span class="text-gray-700">{{ $dinasName }}</span>
                                    <span class="font-semibold text-gray-900">{{ $cnt }}</span>
                                </div>
                                <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                    <div class="h-2 bg-purple-600" style="width: {{ $pct }}%"></div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="text-sm text-gray-500">Belum ada data.</div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Monitoring + filter --}}
        <div class="bg-white border rounded p-4 shadow-sm">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <h2 class="text-lg font-semibold">Monitoring Berkas</h2>

                <form method="GET" class="flex flex-col sm:flex-row gap-2 items-end">
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Kecamatan</label>
                        <select name="kecamatan_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            @foreach($kecamatans as $k)
                                <option value="{{ $k->id }}" @selected((string)($filters['kecamatan_id'] ?? '') === (string)$k->id)>
                                    {{ $k->nama_kecamatan }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Dinas</label>
                        <select name="dinas_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            @foreach($dinasList as $d)
                                <option value="{{ $d->id }}" @selected((string)($filters['dinas_id'] ?? '') === (string)$d->id)>
                                    {{ $d->nama_dinas }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Layanan</label>
                        <select name="layanan_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            @foreach($layananList as $l)
                                <option value="{{ $l->id }}" @selected((string)($filters['layanan_id'] ?? '') === (string)$l->id)>
                                    {{ $l->nama_layanan }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Status</label>
                        <select name="status" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            @foreach(array_keys($statusCounts) as $st)
                                <option value="{{ $st }}" @selected((string)($filters['status'] ?? '') === (string)$st)>
                                    {{ $st }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="flex gap-2">
                        <button class="bg-blue-600 text-white px-3 py-1.5 rounded text-sm">Filter</button>
                        <a href="{{ route('dashboard') }}" class="border px-3 py-1.5 rounded text-sm">Reset</a>
                    </div>
                </form>
            </div>

            <div class="mt-4 overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                        <tr class="text-left text-gray-600">
                            <th class="py-2 pr-4">No Registrasi</th>
                            <th class="py-2 pr-4">Kecamatan</th>
                            <th class="py-2 pr-4">Layanan</th>
                            <th class="py-2 pr-4">Dinas</th>
                            <th class="py-2 pr-4">Status</th>
                            <th class="py-2 pr-4">Tanggal</th>
                            <th class="py-2 pr-4">SLA</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @php $slaDaysLocal = (int)($slaDays ?? 3); @endphp
                        @foreach($permohonans as $p)
                            @php
                                $op = $p->operator;
                                $dinasName = $op?->dinas?->nama_dinas ?? $op?->dinas_id ?? '-';
                                $isOver = $p->created_at && $p->status !== 'SELESAI' && $p->status !== 'DITOLAK' && $p->created_at < now()->subDays($slaDaysLocal);
                            @endphp
                            <tr class="align-top">
                                <td class="py-2 pr-4 font-medium">
                                    <a href="{{ route('operator.permohonans.show', $p->id) }}" class="text-blue-700 hover:underline">
                                        {{ $p->nomor_registrasi }}
                                    </a>
                                </td>
                                <td class="py-2 pr-4">{{ $p->kecamatan->nama_kecamatan ?? '-' }}</td>
                                <td class="py-2 pr-4">{{ $p->layanan->nama_layanan ?? '-' }}</td>
                                <td class="py-2 pr-4">{{ $dinasName }}</td>
                                <td class="py-2 pr-4">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs
                                        @if($p->status === 'SELESAI') bg-green-100 text-green-700
                                        @elseif($p->status === 'DITOLAK') bg-red-100 text-red-700
                                        @elseif($p->status === 'PERLU_PERBAIKAN') bg-yellow-100 text-yellow-800
                                        @else bg-blue-100 text-blue-700
                                        @endif">
                                        {{ $p->status }}
                                    </span>
                                </td>
                                <td class="py-2 pr-4 text-gray-700">{{ $p->created_at->format('Y-m-d') }}</td>
                                <td class="py-2 pr-4">
                                    @if($isOver)
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs bg-red-100 text-red-700 font-semibold">LEWAT</span>
                                    @else
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700">OK</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        @if($permohonans->isEmpty())
                            <tr>
                                <td colspan="7" class="py-4 text-gray-500">Tidak ada data.</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $permohonans->links() }}
            </div>
        </div>
    </div>
</x-sipaten-base-layout>

