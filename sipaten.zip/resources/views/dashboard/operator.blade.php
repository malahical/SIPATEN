<x-sipaten-base-layout>
    <x-slot:title>Dashboard Operator</x-slot:title>

    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold mb-4">Dashboard Operator</h1>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Total Pengajuan Hari Ini</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Dikirim</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Perlu Perbaikan</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
        </div>
    </div>
</x-sipaten-base-layout>

