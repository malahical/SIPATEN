<x-sipaten-base-layout>
    <x-slot:title>Dashboard Verifikator</x-slot:title>

    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold mb-4">Dashboard Verifikator</h1>
        <div class="bg-white border rounded p-4 shadow-sm">
            Verifikator view sementara.
        </div>
    </div>
</x-sipaten-base-layout>

