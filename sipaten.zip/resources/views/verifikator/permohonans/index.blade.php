@php
    $activeCategory = $activeCategory ?? 'perlu-perbaikan';

    $title = match($activeCategory) {
        'perlu-perbaikan' => 'Perlu Perbaikan',
        'billing' => 'Billing',
        'dokumen-selesai' => 'Dokumen Selesai',
        'arsip' => 'Arsip',
        default => 'Permohonan Masuk',
    };

    $actionRoute = match($activeCategory) {
        'perlu-perbaikan' => 'verifikator.perlu-perbaikan',
        'billing' => 'verifikator.billing',
        'dokumen-selesai' => 'verifikator.dokumen-selesai',
        'arsip' => 'verifikator.arsip',
        default => 'verifikator.permohonans.index',
    };
@endphp

<x-sipaten-base-layout :title="$title">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-bold text-slate-800">{{ $title }}</h1>
    </div>

    @if (session('success'))
        <div class="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-lg">
            {{ session('success') }}
        </div>
    @endif

    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div class="p-4 border-b border-slate-100">
            <form action="{{ route($actionRoute) }}" method="GET">
                <div class="flex gap-3">
                    <input
                        type="text"
                        name="q"
                        value="{{ request('q') }}"
                        placeholder="Cari nomor registrasi / nama pemohon"
                        class="flex-1 rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500"
                    >
                    <button type="submit"
                        class="px-4 py-2 rounded-lg bg-sky-600 text-white hover:bg-sky-700">
                        Cari
                    </button>
                </div>
            </form>
        </div>

        <table class="min-w-full divide-y divide-slate-200">
            <thead class="bg-slate-50">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Nomor Registrasi</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Pemohon</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Kecamatan</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Layanan</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Status</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse ($permohonans as $permohonan)
                    <tr>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-800">{{ $permohonan->nomor_registrasi }}</td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-800">{{ $permohonan->nama_pemohon }}</td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-700">{{ $permohonan->kecamatan->nama_kecamatan ?? '-' }}</td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-700">{{ $permohonan->layanan->nama_layanan ?? '-' }}</td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm">
                            @php
                                $status = $permohonan->status;
                                $badge = match($status) {
                                    'DIKIRIM' => 'bg-blue-50 text-blue-700 border-blue-200',
                                    'PERLU_PERBAIKAN' => 'bg-amber-50 text-amber-700 border-amber-200',
                                    'SELESAI' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                                    'DITOLAK' => 'bg-rose-50 text-rose-700 border-rose-200',
                                    default => 'bg-slate-50 text-slate-700 border-slate-200',
                                };
                            @endphp
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full border {{ $badge }}">
                                {{ $status }}
                            </span>
                        </td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm">
                            <a href="{{ route('verifikator.permohonans.show', $permohonan) }}"
                               class="inline-flex items-center px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800">
                                Detail
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-4 py-6 text-center text-slate-500">Belum ada permohonan.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        <div class="p-4">
            {{ $permohonans->appends(request()->query())->links() }}
        </div>
    </div>
</x-sipaten-base-layout>
