<x-sipaten-base-layout title="Detail Permohonan">
    <div class="flex items-center justify-between mb-4">
        <div>
            <h1 class="text-xl font-bold text-slate-800">Detail Permohonan</h1>
            <p class="text-sm text-slate-500">{{ $permohonan->nomor_registrasi }}</p>
        </div>
        <a href="{{ route('verifikator.permohonans.index') }}"
           class="inline-flex items-center px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800">
            Kembali
        </a>
    </div>

    @if (session('success'))
        <div class="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-lg">
            {{ session('success') }}
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="lg:col-span-1 bg-white rounded-xl shadow-sm p-4">
            <div class="text-sm text-slate-500">Pemohon</div>
            <div class="mt-1 font-semibold text-slate-800">{{ $permohonan->nama_pemohon }}</div>
            <div class="text-sm text-slate-600 mt-1">NIK: {{ $permohonan->nik }}</div>
            <div class="text-sm text-slate-600 mt-1">No WA: {{ $permohonan->no_wa_pemohon }}</div>
            <div class="text-sm text-slate-600 mt-1">Alamat: {{ $permohonan->alamat }}</div>

            <hr class="my-4 border-slate-100">

            <div class="text-sm text-slate-500">Layanan</div>
            <div class="mt-1 font-semibold text-slate-800">{{ $permohonan->layanan->nama_layanan ?? '-' }}</div>
            <div class="text-sm text-slate-600 mt-1">Kecamatan: {{ $permohonan->kecamatan->nama_kecamatan ?? '-' }}</div>

            <div class="mt-4">
                <div class="text-sm text-slate-500">Status terakhir</div>
                <div class="mt-1">
                    @php
                        $status = $latestStatus ?? $permohonan->status;
                        $badge = match($status) {
                            'DIKIRIM' => 'bg-blue-50 text-blue-700 border-blue-200',
                            'PERLU_PERBAIKAN' => 'bg-amber-50 text-amber-700 border-amber-200',
                            'SELESAI' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                            'DITOLAK' => 'bg-rose-50 text-rose-700 border-rose-200',
                            default => 'bg-slate-50 text-slate-700 border-slate-200',
                        };
                    @endphp
                    <span class="inline-flex items-center px-2.5 py-1 rounded-full border {{ $badge }}">
                        {{ $status }}
                    </span>
                </div>

                @if(!empty($permohonan->catatan_terakhir))
                    <div class="mt-3 text-sm text-slate-600">
                        <div class="font-medium text-slate-700">Catatan</div>
                        {{ $permohonan->catatan_terakhir }}
                    </div>
                @endif
            </div>
        </div>

        <div class="lg:col-span-2 space-y-4">
            <div class="bg-white rounded-xl shadow-sm p-4">
                <h2 class="font-bold text-slate-800 mb-3">Update Status</h2>

                <form method="POST" action="{{ route('verifikator.permohonans.updateStatus', $permohonan) }}">
                    @csrf
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label class="text-sm text-slate-700">Status</label>
                            <select name="status" class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                                @foreach(['DIVERIFIKASI','PERLU_PERBAIKAN','MENUNGGU_PEMBAYARAN','DIPROSES','SELESAI','DITOLAK'] as $st)
                                    <option value="{{ $st }}" {{ ($permohonan->status ?? '') === $st ? 'selected' : '' }}>{{ $st }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label class="text-sm text-slate-700">Catatan (opsional)</label>
                            <input type="text" name="catatan" value="{{ old('catatan') }}" placeholder="Catatan revisi / alasan"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="px-4 py-2 rounded-lg bg-sky-600 text-white hover:bg-sky-700">
                            Simpan Status
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-4">
                <h2 class="font-bold text-slate-800 mb-3">Billing (Minimal)</h2>

                @php
                    $billing = $permohonan->billings->first();
                @endphp

                <form method="POST" action="{{ route('verifikator.permohonans.upsertBilling', $permohonan) }}">
                    @csrf
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label class="text-sm text-slate-700">Nomor Billing</label>
                            <input type="text" name="nomor_billing" value="{{ old('nomor_billing', $billing->nomor_billing ?? '') }}"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div>
                            <label class="text-sm text-slate-700">Jenis Billing</label>
                            <input type="text" name="jenis_billing" value="{{ old('jenis_billing', $billing->jenis_billing ?? '') }}"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div>
                            <label class="text-sm text-slate-700">Nominal</label>
                            <input type="number" step="0.01" name="nominal" value="{{ old('nominal', $billing->nominal ?? '') }}"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div>
                            <label class="text-sm text-slate-700">Batas Bayar</label>
                            <input type="date" name="batas_bayar" value="{{ old('batas_bayar', optional($billing->batas_bayar)->format('Y-m-d')) }}"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div class="sm:col-span-2">
                            <label class="text-sm text-slate-700">Catatan</label>
                            <input type="text" name="catatan" value="{{ old('catatan', $billing->catatan ?? '') }}"
                                   placeholder="Keterangan billing"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                            Simpan Billing
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-4">
                <h2 class="font-bold text-slate-800 mb-3">Upload Dokumen Hasil</h2>

                <form method="POST"
                      action="{{ route('verifikator.permohonans.storeResultFile', $permohonan) }}"
                      enctype="multipart/form-data">
                    @csrf

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label class="text-sm text-slate-700">Nama File</label>
                            <input type="text" name="nama_file" value="{{ old('nama_file') }}"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div>
                            <label class="text-sm text-slate-700">Jenis File</label>
                            <input type="text" name="jenis_file" value="{{ old('jenis_file') }}"
                                   placeholder="misal: SURAT/BERITA_ACARA"
                                   class="mt-1 w-full rounded-lg border-slate-200 focus:border-sky-500 focus:ring-sky-500">
                        </div>

                        <div class="sm:col-span-2">
                            <label class="text-sm text-slate-700">File (PDF/JPG/PNG, max 5MB)</label>
                            <input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png"
                                   class="mt-1 w-full">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700">
                            Simpan Dokumen Hasil
                        </button>
                    </div>
                </form>

                <div class="mt-5">
                    <div class="text-sm font-semibold text-slate-800 mb-2">Dokumen yang sudah tercatat</div>
                    <div class="space-y-2">
                        @forelse ($permohonan->files as $f)
                            <div class="flex items-center justify-between bg-slate-50 border border-slate-100 rounded-lg px-3 py-2">
                                <div class="text-sm text-slate-800">
                                    <div class="font-medium">{{ $f->nama_file }}</div>
                                    <div class="text-xs text-slate-500">{{ $f->jenis_file }}</div>
                                </div>
                                @if(!empty($f->drive_url))
                                    <a href="{{ $f->drive_url }}" target="_blank" class="text-sky-600 text-sm font-semibold">Lihat</a>
                                @else
                                    <span class="text-xs text-slate-400">Belum ada link Drive</span>
                                @endif
                            </div>
                        @empty
                            <div class="text-sm text-slate-500">Belum ada dokumen hasil.</div>
                        @endforelse
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-4">
                <h2 class="font-bold text-slate-800 mb-3">Riwayat Status</h2>
                <div class="space-y-2">
                    @forelse ($permohonan->statusLogs->sortByDesc('created_at') as $log)
                        <div class="border border-slate-100 rounded-lg p-3">
                            <div class="flex items-center justify-between">
                                <div class="text-sm font-semibold text-slate-800">{{ $log->status }}</div>
                                <div class="text-xs text-slate-500">{{ $log->created_at?->format('Y-m-d H:i') }}</div>
                            </div>
                            @if(!empty($log->catatan))
                                <div class="text-sm text-slate-600 mt-1">{{ $log->catatan }}</div>
                            @endif
                            <div class="text-xs text-slate-400 mt-1">Diubah oleh: {{ $log->changer->name ?? '-' }}</div>
                        </div>
                    @empty
                        <div class="text-sm text-slate-500">Riwayat status belum ada.</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</x-sipaten-base-layout>
