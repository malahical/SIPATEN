<!-- Verifikator Dashboard -->
<x-sipaten-base-layout title="Dashboard Verifikator">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-4">
            <div class="text-sm text-slate-500">Total pengajuan hari ini</div>
            <div class="mt-2 text-2xl font-bold text-sky-700">{{ $todayCount ?? 0 }}</div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-4">
            <div class="text-sm text-slate-500">Dikirim</div>
            <div class="mt-2 text-2xl font-bold text-blue-600">{{ $dikirm ?? 0 }}</div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-4">
            <div class="text-sm text-slate-500">Perlu perbaikan</div>
            <div class="mt-2 text-2xl font-bold text-amber-600">{{ $perluPerbaikan ?? 0 }}</div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-4">
            <div class="text-sm text-slate-500">Selesai</div>
            <div class="mt-2 text-2xl font-bold text-emerald-600">{{ $selesai ?? 0 }}</div>
        </div>
    </div>

    <div class="mt-6">
        <a href="{{ route('verifikator.permohonans.index') }}"
           class="inline-flex items-center px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700">
            Lihat permohonan masuk
        </a>
    </div>
</x-sipaten-base-layout>
