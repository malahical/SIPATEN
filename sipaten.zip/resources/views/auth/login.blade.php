<x-guest-layout>
    <div class="min-h-[68vh] flex items-center justify-center px-4 py-10">
        <div class="w-full max-w-sm sm:max-w-md">
            {{-- Header berwarna --}}
            <div class="mb-5">
                <div class="relative overflow-hidden rounded-3xl border border-emerald-100">
                    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-600"></div>
                    <div class="p-5 sm:p-6">
                        <div class="mx-auto w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center shadow-sm">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                <path d="M12 2l7 4v6c0 5-3 9-7 10C8 21 5 17 5 12V6l7-4z" stroke="white" stroke-width="2" stroke-linejoin="round"/>
                            </svg>
                        </div>

                        <h1 class="mt-3 text-center text-lg font-semibold text-white">Masuk Sistem</h1>
                        <p class="mt-1 text-center text-xs text-white/85">SIPATEN (Sistem Pelayanan Kecamatan Terpadu)</p>
                    </div>
                </div>
            </div>

            <div class="bg-white/90 backdrop-blur border border-emerald-100 rounded-2xl shadow-sm p-5 sm:p-6">
                <x-auth-session-status class="mb-3" :status="session('status')" />

                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="space-y-4">
                        <div>
                            <x-input-label for="email" :value="__('Email')" />
                            <x-text-input
                                id="email"
                                class="mt-1 block w-full rounded-xl bg-white border-emerald-100 focus:border-emerald-700 focus:ring-emerald-700"
                                type="email"
                                name="email"
                                :value="old('email')"
                                required
                                autofocus
                                autocomplete="username"
                            />
                            <x-input-error :messages="$errors->get('email')" class="mt-1" />
                        </div>

                        <div>
                            <x-input-label for="password" :value="__('Password')" />
                            <x-text-input
                                id="password"
                                class="mt-1 block w-full rounded-xl bg-white border-emerald-100 focus:border-emerald-700 focus:ring-emerald-700"
                                type="password"
                                name="password"
                                required
                                autocomplete="current-password"
                            />
                            <x-input-error :messages="$errors->get('password')" class="mt-1" />
                        </div>

                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <label class="inline-flex items-center">
                                <input
                                    id="remember_me"
                                    type="checkbox"
                                    class="rounded border-emerald-200 text-emerald-700 shadow-sm focus:ring-emerald-700"
                                    name="remember"
                                >
                                <span class="ml-2 text-sm text-slate-700">{{ __('Remember me') }}</span>
                            </label>

                            @if (Route::has('password.request'))
                                <a
                                    class="text-sm text-emerald-700 hover:text-emerald-800 underline decoration-emerald-200 hover:decoration-emerald-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:ring-offset-2"
                                    href="{{ route('password.request') }}"
                                >
                                    {{ __('Forgot your password?') }}
                                </a>
                            @endif
                        </div>

                        <x-primary-button
                            class="w-full rounded-xl px-4 py-2.5 bg-gradient-to-r from-emerald-700 to-teal-600 hover:from-emerald-800 hover:to-teal-700 focus:ring-2 focus:ring-emerald-700 focus:ring-offset-2"
                        >
                            {{ __('Log in') }}
                        </x-primary-button>
                    </div>
                </form>
            </div>

            <p class="text-center text-xs text-slate-500 mt-4">
                © {{ date('Y') }} SIPATEN
            </p>
        </div>
    </div>
</x-guest-layout>
