<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ $title ?? config('app.name', 'SIPATEN') }}</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="bg-[#FDFDFC] text-[#1b1b18] min-h-screen">
        <div class="min-h-screen flex">
            @auth
                @include('layouts.sidebar')
            @endauth

            <div class="flex-1">
                @auth
                    @include('layouts.topbar')
                @endauth

                <main class="p-4 md:p-6">
                    {{ $slot ?? $content ?? '' }}
                </main>
            </div>
        </div>
    </body>
</html>

