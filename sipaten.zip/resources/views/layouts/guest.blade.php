<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'SIPATEN') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans text-gray-900 antialiased">
        <div class="min-h-screen flex items-center justify-center bg-[#FDFDFC] px-4 sm:px-6 py-8">
            {{-- Wrapper auth: biarkan halaman (slot) mengatur tampilan header & card --}}
            <div class="w-full max-w-[420px] rounded-2xl overflow-hidden bg-white/95 shadow-sm ring-1 ring-slate-200">
                <div class="p-5 sm:p-6">
                    {{ $slot }}
                </div>
            </div>
        </div>
    </body>
</html>
