@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-2xl mx-auto p-4 sm:p-6">
    <div class="mb-5">
        <h1 class="text-2xl font-semibold text-slate-800">
            {{ $user ? 'Edit User' : 'Tambah User' }}
        </h1>
        <p class="text-slate-600 mt-1">Isi data user sesuai role dan wilayah.</p>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        @if ($user)
            <form method="POST" action="{{ route('admin.users.update', $user) }}">
                @csrf
                @method('PUT')
        @else
            <form method="POST" action="{{ route('admin.users.store') }}">
                @csrf
        @endif

        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Nama</label>
                <input
                    type="text"
                    name="name"
                    value="{{ old('name', $user?->name) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('name')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                <input
                    type="email"
                    name="email"
                    value="{{ old('email', $user?->email) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('email')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Role</label>
                <select
                    name="role"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                >
                    @php
                        $selectedRole = old('role', $user?->role);
                        $roles = ['operator' => 'Operator', 'verifikator' => 'Verifikator', 'admin' => 'Admin'];
                    @endphp
                    <option value="">-- Pilih Role --</option>
                    @foreach ($roles as $value => $label)
                        <option value="{{ $value }}" @selected($selectedRole === $value)>{{ $label }}</option>
                    @endforeach
                </select>
                @error('role')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Kecamatan (nullable)</label>
                    <select
                        name="kecamatan_id"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    >
                        <option value="">-- Tidak pilih --</option>
                        @foreach ($kecamatans as $kec)
                            <option value="{{ $kec->id }}" @selected((int) old('kecamatan_id', $user?->kecamatan_id) === $kec->id)>
                                {{ $kec->nama_kecamatan }}
                            </option>
                        @endforeach
                    </select>
                    @error('kecamatan_id')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Dinas (nullable)</label>
                    <select
                        name="dinas_id"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    >
                        <option value="">-- Tidak pilih --</option>
                        @foreach ($dinases as $din)
                            <option value="{{ $din->id }}" @selected((int) old('dinas_id', $user?->dinas_id) === $din->id)>
                                {{ $din->nama_dinas }}
                            </option>
                        @endforeach
                    </select>
                    @error('dinas_id')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">No WhatsApp (nullable)</label>
                <input
                    type="text"
                    name="no_wa"
                    value="{{ old('no_wa', $user?->no_wa) }}"
                    placeholder="Contoh: 62821xxxx"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
                @error('no_wa')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
                <input
                    type="password"
                    name="password"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    @if(!$user) required @endif
                    placeholder="{{ $user ? 'Kosongkan jika tidak ubah' : '' }}"
                />
                @error('password')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Status Aktif</label>
                <select
                    name="is_active"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                >
                    <option value="1" @selected((int) old('is_active', $user?->is_active ?? 1) === 1)>Aktif</option>
                    <option value="0" @selected((int) old('is_active', $user?->is_active ?? 1) === 0)>Nonaktif</option>
                </select>
                @error('is_active')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="pt-2 flex gap-2">
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                    Simpan
                </button>

                <a href="{{ route('admin.users.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Batal
                </a>
            </div>
        </div>
        </form>
    </div>
</div>
@endsection
