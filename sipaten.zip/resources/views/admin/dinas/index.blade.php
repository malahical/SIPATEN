@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-6xl mx-auto p-4 sm:p-6">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
        <div>
            <h1 class="text-2xl font-semibold text-slate-800">Manajemen Dinas</h1>
            <p class="text-slate-600 mt-1">Kelola data dinas untuk kebutuhan layanan dan verifikasi.</p>
        </div>

        <div class="flex gap-2">
            <a href="{{ route('dinas.create') }}"
               class="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                + Tambah Dinas
            </a>
        </div>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-4 mb-4">
        <form method="GET" action="{{ route('admin.dinas.index') }}" class="flex flex-col sm:flex-row gap-2">
            <input
                type="text"
                name="search"
                value="{{ request('search') }}"
                placeholder="Cari nama dinas..."
                class="flex-1 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
            />
            <button class="px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                Cari
            </button>
            @if (request('search'))
                <a href="{{ route('admin.dinas.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Reset
                </a>
            @endif
        </form>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-100">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Nama Dinas</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">No WA Admin</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse ($dinases as $dinas)
                        <tr>
                            <td class="px-4 py-3 text-slate-800 font-medium">{{ $dinas->nama_dinas }}</td>
                            <td class="px-4 py-3 text-slate-700">{{ $dinas->no_wa_admin ?? '-' }}</td>
                            <td class="px-4 py-3 text-right">
                                <div class="inline-flex gap-2">
                                    <a href="{{ route('admin.dinas.edit', $dinas) }}"
                                       class="px-3 py-1.5 rounded-lg border border-blue-200 text-blue-700 hover:bg-blue-50 text-sm">
                                        Edit
                                    </a>
                                    <form action="{{ route('admin.dinas.destroy', $dinas) }}" method="POST" onsubmit="return confirm('Hapus dinas ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            class="px-3 py-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-sm">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="px-4 py-6 text-center text-slate-500">Belum ada data dinas.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="p-4 bg-white">
            {{ $dinases->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
