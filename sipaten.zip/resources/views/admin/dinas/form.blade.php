@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-2xl mx-auto p-4 sm:p-6">
    <div class="mb-5">
        <h1 class="text-2xl font-semibold text-slate-800">
            {{ $dinas ? 'Edit Dinas' : 'Tambah Dinas' }}
        </h1>
        <p class="text-slate-600 mt-1">Isi data dinas dengan benar.</p>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        @if ($dinas)
            <form method="POST" action="{{ route('admin.dinas.update', $dinas) }}">
                @csrf
                @method('PUT')
        @else
            <form method="POST" action="{{ route('admin.dinas.store') }}">
                @csrf
        @endif

        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Nama Dinas</label>
                <input
                    type="text"
                    name="nama_dinas"
                    value="{{ old('nama_dinas', $dinas?->nama_dinas) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('nama_dinas')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">No WhatsApp Admin</label>
                <input
                    type="text"
                    name="no_wa_admin"
                    value="{{ old('no_wa_admin', $dinas?->no_wa_admin) }}"
                    placeholder="Contoh: 62812xxxxxx"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
                @error('no_wa_admin')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="pt-2 flex gap-2">
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                    Simpan
                </button>

                <a href="{{ route('admin.dinas.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Batal
                </a>
            </div>
        </div>
        </form>
    </div>
</div>
@endsection
