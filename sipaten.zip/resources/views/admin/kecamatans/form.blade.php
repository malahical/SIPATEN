@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-2xl mx-auto p-4 sm:p-6">
    <div class="mb-5">
        <h1 class="text-2xl font-semibold text-slate-800">
            {{ $kecamatan ? 'Edit Kecamatan' : 'Tambah Kecamatan' }}
        </h1>
        <p class="text-slate-600 mt-1">Isi data kecamatan dengan benar.</p>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        @if ($kecamatan)
            <form method="POST" action="{{ route('admin.kecamatans.update', $kecamatan) }}">
                @csrf
                @method('PUT')
        @else
            <form method="POST" action="{{ route('admin.kecamatans.store') }}">
                @csrf
        @endif

        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Nama Kecamatan</label>
                <input
                    type="text"
                    name="nama_kecamatan"
                    value="{{ old('nama_kecamatan', $kecamatan?->nama_kecamatan) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('nama_kecamatan')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Alamat (opsional)</label>
                <textarea
                    name="alamat"
                    rows="4"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                >{{ old('alamat', $kecamatan?->alamat) }}</textarea>
                @error('alamat')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="pt-2 flex gap-2">
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                    Simpan
                </button>

                <a href="{{ route('admin.kecamatans.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Batal
                </a>
            </div>
        </div>
        </form>
    </div>
</div>
@endsection
