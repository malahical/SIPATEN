@extends('layouts.sipaten-app')

@section('content')
<div class="max-w-2xl mx-auto p-4 sm:p-6">
    <div class="mb-5">
        <h1 class="text-2xl font-semibold text-slate-800">
            {{ $layanan ? 'Edit Layanan' : 'Tambah Layanan' }}
        </h1>
        <p class="text-slate-600 mt-1">Isi data layanan yang tersedia.</p>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-5">
        @if ($layanan)
            <form method="POST" action="{{ route('admin.layanans.update', $layanan) }}">
                @csrf
                @method('PUT')
        @else
            <form method="POST" action="{{ route('admin.layanans.store') }}">
                @csrf
        @endif

        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Nama Layanan</label>
                <input
                    type="text"
                    name="nama_layanan"
                    value="{{ old('nama_layanan', $layanan?->nama_layanan) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('nama_layanan')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Jenis Layanan</label>
                <select
                    name="jenis_layanan"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                >
                    @php
                        $selectedJenis = old('jenis_layanan', $layanan?->jenis_layanan);
                        $options = [
                            'perizinan' => 'Perizinan',
                            'non_perizinan' => 'Non Perizinan',
                            'kependudukan' => 'Kependudukan',
                            'bansos' => 'Bansos',
                            'pajak_retribusi' => 'Pajak/Retribusi',
                        ];
                    @endphp

                    @foreach ($options as $value => $label)
                        <option value="{{ $value }}" @selected($selectedJenis === $value)>{{ $label }}</option>
                    @endforeach
                </select>
                @error('jenis_layanan')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Dinas</label>
                <select
                    name="dinas_id"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                >
                    <option value="">-- Pilih Dinas --</option>
                    @foreach (($dinases ?? \App\Models\Dinas::all()) as $dinasOption)
                        <option value="{{ $dinasOption->id }}" @selected((int) old('dinas_id', $layanan?->dinas_id) === $dinasOption->id) >
                            {{ $dinasOption->nama_dinas }}
                        </option>
                    @endforeach
                </select>
                @error('dinas_id')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">SLA (Hari)</label>
                <input
                    type="number"
                    name="sla_hari"
                    min="1"
                    value="{{ old('sla_hari', $layanan?->sla_hari) }}"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                />
                @error('sla_hari')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Persyaratan</label>
                <textarea
                    name="persyaratan"
                    rows="4"
                    class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                >{{ old('persyaratan', $layanan?->persyaratan) }}</textarea>
                @error('persyaratan')
                    <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex items-center justify-between gap-4">
                <div class="flex-1">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Status Aktif</label>
                    <select
                        name="is_active"
                        class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                        required
                    >
                        <option value="1" @selected((int) old('is_active', $layanan?->is_active ?? 1) === 1)>Aktif</option>
                        <option value="0" @selected((int) old('is_active', $layanan?->is_active ?? 1) === 0)>Nonaktif</option>
                    </select>
                    @error('is_active')
                        <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div class="pt-2 flex gap-2">
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                    Simpan
                </button>

                <a href="{{ route('admin.layanans.index') }}"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Batal
                </a>
            </div>
        </div>
        </form>
    </div>
</div>
@endsection
