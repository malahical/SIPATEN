<?php
    $role = (string) (Auth::user()->role ?? 'operator');
?>

<aside class="hidden md:flex md:w-72 bg-white border-r border-gray-200 flex-col">
    <div class="p-4 border-b">
        <div class="font-semibold text-lg text-blue-700">SIPATEN</div>
        <div class="text-sm text-gray-500">Sistem Pelayanan Kecamatan Terpadu</div>
    </div>

    <nav class="p-3 space-y-1">
        <?php if($role === 'operator'): ?>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Pengajuan Baru</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Berkas Saya</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Tracking</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Arsip</a>
        <?php elseif($role === 'verifikator'): ?>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.dashboard')); ?>">Dashboard</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.permohonans.index')); ?>">Permohonan Masuk</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.perlu-perbaikan')); ?>">Perlu Perbaikan</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.billing')); ?>">Billing</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.dokumen-selesai')); ?>">Dokumen Selesai</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('verifikator.arsip')); ?>">Arsip</a>
        <?php else: ?>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Monitoring Berkas</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('kecamatans.index')); ?>">Rekap Kecamatan</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('dinas.index')); ?>">Rekap Dinas</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Laporan SLA</a>

            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('users.index')); ?>">Manajemen User</a>
            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="<?php echo e(route('layanans.index')); ?>">Manajemen Layanan</a>

            <a class="block px-3 py-2 rounded-md hover:bg-gray-100" href="#">Arsip</a>
        <?php endif; ?>
    </nav>
</aside>

<?php /**PATH C:\Users\ZAID\Desktop\SIPATEN\sipaten-laravel\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>