

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto p-4 sm:p-6">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
        <div>
            <h1 class="text-2xl font-semibold text-slate-800">Manajemen Dinas</h1>
            <p class="text-slate-600 mt-1">Kelola data dinas untuk kebutuhan layanan dan verifikasi.</p>
        </div>

        <div class="flex gap-2">
            <a href="<?php echo e(route('dinas.create')); ?>"
               class="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                + Tambah Dinas
            </a>
        </div>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 p-4 mb-4">
        <form method="GET" action="<?php echo e(route('admin.dinas.index')); ?>" class="flex flex-col sm:flex-row gap-2">
            <input
                type="text"
                name="search"
                value="<?php echo e(request('search')); ?>"
                placeholder="Cari nama dinas..."
                class="flex-1 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
            />
            <button class="px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                Cari
            </button>
            <?php if(request('search')): ?>
                <a href="<?php echo e(route('admin.dinas.index')); ?>"
                   class="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-center">
                    Reset
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="bg-white shadow-sm rounded-xl border border-slate-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-100">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Nama Dinas</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">No WA Admin</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $dinases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-3 text-slate-800 font-medium"><?php echo e($dinas->nama_dinas); ?></td>
                            <td class="px-4 py-3 text-slate-700"><?php echo e($dinas->no_wa_admin ?? '-'); ?></td>
                            <td class="px-4 py-3 text-right">
                                <div class="inline-flex gap-2">
                                    <a href="<?php echo e(route('admin.dinas.edit', $dinas)); ?>"
                                       class="px-3 py-1.5 rounded-lg border border-blue-200 text-blue-700 hover:bg-blue-50 text-sm">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('admin.dinas.destroy', $dinas)); ?>" method="POST" onsubmit="return confirm('Hapus dinas ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="px-3 py-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-sm">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="px-4 py-6 text-center text-slate-500">Belum ada data dinas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="p-4 bg-white">
            <?php echo e($dinases->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sipaten-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ZAID\Desktop\SIPATEN\sipaten-laravel\resources\views/admin/dinas/index.blade.php ENDPATH**/ ?>