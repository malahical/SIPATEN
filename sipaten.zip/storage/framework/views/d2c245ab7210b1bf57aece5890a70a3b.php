<?php if (isset($component)) { $__componentOriginal180aa0cf8cb4c481783b7c169d3946f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sipaten-base-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sipaten-base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Dashboard Admin <?php $__env->endSlot(); ?>

    <div class="max-w-6xl mx-auto space-y-6">
        <div class="flex items-start justify-between gap-4">
            <div>
                <h1 class="text-2xl font-semibold">Dashboard Eksekutif</h1>
                <p class="text-sm text-gray-500 mt-1">
                    Monitoring permohonan, status, billing, dan highlight SLA (± <?php echo e($slaDays); ?> hari).
                </p>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-6 gap-3">
            <?php
                $total = max(1, (int)($totalCount ?? 0));
            ?>

            <?php $__currentLoopData = [
                'DIKIRIM' => 'Dikirim',
                'PERLU_PERBAIKAN' => 'Perlu Perbaikan',
                'MENUNGGU_PEMBAYARAN' => 'Menunggu Pembayaran',
                'DIPROSES' => 'Diproses',
                'SELESAI' => 'Selesai',
                'DITOLAK' => 'Ditolak',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white border rounded p-4 shadow-sm">
                    <div class="text-sm text-gray-500"><?php echo e($label); ?></div>
                    <div class="text-2xl font-bold text-blue-700"><?php echo e($statusCounts[$key] ?? 0); ?></div>
                    <div class="mt-2">
                        <?php
                            $cnt = (int)($statusCounts[$key] ?? 0);
                            $pct = round(($cnt / $total) * 100);
                        ?>
                        <div class="h-2 bg-gray-100 rounded overflow-hidden">
                            <div class="h-2 bg-blue-600" style="width: <?php echo e($pct); ?>%"></div>
                        </div>
                        <div class="text-xs text-gray-500 mt-1"><?php echo e($pct); ?>%</div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="bg-white border rounded p-4 shadow-sm">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <div class="text-sm text-gray-500">Highlight SLA lewat</div>
                    <div class="text-3xl font-bold text-red-600 mt-1"><?php echo e($slaOver ?? 0); ?></div>
                </div>
                <div class="text-right">
                    <div class="text-xs text-gray-500">Kriteria: status bukan SELESAI/DITOLAK dan umur data > <?php echo e($slaDays); ?> hari</div>
                </div>
            </div>
        </div>

        
        <div class="bg-white border rounded p-4 shadow-sm">
            <h2 class="text-lg font-semibold mb-3">Grafik: Layanan per Bulan (6 bulan terakhir)</h2>

            <?php
                // Flatten counts for rendering
                $allLayananIds = collect($layananList ?? collect())->pluck('id')->values()->all();
                $monthList = is_array($months ?? null) ? $months : [];
                // Build rows: layanan_id => [ym => cnt]
                $rows = [];
                foreach ($monthList as $ym) {
                    $counts = $layananPerMonth[$ym] ?? collect();
                    // $counts is collection (plucked cnt by layanan_id)
                    foreach ($counts as $layananId => $cnt) {
                        $rows[$layananId][$ym] = (int)$cnt;
                    }
                }
            ?>

            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                        <tr class="text-left text-gray-600">
                            <th class="py-2 pr-4">Layanan</th>
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="py-2 pr-4"><?php echo e($ym); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php $__empty_1 = true; $__currentLoopData = ($layananList ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 pr-4 font-medium"><?php echo e($lay->nama_layanan); ?></td>
                                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $cnt = (int)($rows[$lay->id][$ym] ?? 0);
                                        $maxCntThisMonth = (int)($layananPerMonth[$ym] ?? collect())->max() ?: 1;
                                        $pctThisMonth = (int)round(($cnt / max(1, $maxCntThisMonth)) * 100);
                                    ?>
                                    <td class="py-2 pr-4">
                                        <div class="h-3 bg-gray-100 rounded overflow-hidden">
                                            <div class="h-3 bg-blue-600" style="width: <?php echo e(max(0, min(100, $pctThisMonth))); ?>%"></div>
                                        </div>
                                        <div class="text-xs text-gray-500 mt-1"><?php echo e($cnt); ?></div>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(2 + count($months)); ?>" class="py-4 text-gray-500">Belum ada data layanan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-3">
            
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Komposisi Status</h2>
                <?php
                    $compTotal = max(1, (int) array_sum($statusComposition ?? []));
                ?>
                <div class="space-y-3">
                    <?php
                        $compItems = [
                            'DIKIRIM' => 'Dikirim',
                            'PERLU_PERBAIKAN' => 'Perlu Perbaikan',
                            'DIPROSES' => 'Diproses',
                            'SELESAI' => 'Selesai',
                            'DITOLAK' => 'Ditolak',
                        ];
                    ?>
                    <?php $__currentLoopData = $compItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cnt = (int)($statusComposition[$key] ?? 0);
                            $pct = round(($cnt / $compTotal) * 100);
                        ?>
                        <div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-700"><?php echo e($label); ?></span>
                                <span class="font-semibold text-gray-900"><?php echo e($cnt); ?></span>
                            </div>
                            <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                <div class="h-2 bg-blue-600" style="width: <?php echo e($pct); ?>%"></div>
                            </div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e($pct); ?>%</div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Permohonan per Kecamatan</h2>
                <div class="space-y-3">
                    <?php
                        $kecItems = $kecamatanCounts ?? collect();
                    ?>
                    <?php if(count($kecItems)): ?>
                        <?php $__currentLoopData = $kecItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatanId => $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $kecName = ($kecamatans->firstWhere('id', $kecamatanId)->nama_kecamatan) ?? '-';
                                $den = max(1, (int) array_sum($kecItems->toArray()));
                                $pct = round(((int)$cnt / $den) * 100);
                            ?>
                            <div>
                                <div class="flex items-center justify-between text-sm">
                                    <span class="text-gray-700"><?php echo e($kecName); ?></span>
                                    <span class="font-semibold text-gray-900"><?php echo e($cnt); ?></span>
                                </div>
                                <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                    <div class="h-2 bg-green-600" style="width: <?php echo e($pct); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-sm text-gray-500">Belum ada data.</div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="bg-white border rounded p-4 shadow-sm">
                <h2 class="text-lg font-semibold mb-3">Permohonan per Dinas</h2>
                <div class="space-y-3">
                    <?php
                        $dinasItems = $dinasCounts ?? collect();
                    ?>
                    <?php if(count($dinasItems)): ?>
                        <?php $__currentLoopData = $dinasItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinasId => $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $dinasName = ($dinasList->firstWhere('id', $dinasId)->nama_dinas) ?? '-';
                                $den = max(1, (int) array_sum($dinasItems->toArray()));
                                $pct = round(((int)$cnt / $den) * 100);
                            ?>
                            <div>
                                <div class="flex items-center justify-between text-sm">
                                    <span class="text-gray-700"><?php echo e($dinasName); ?></span>
                                    <span class="font-semibold text-gray-900"><?php echo e($cnt); ?></span>
                                </div>
                                <div class="h-2 bg-gray-100 rounded overflow-hidden mt-2">
                                    <div class="h-2 bg-purple-600" style="width: <?php echo e($pct); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-sm text-gray-500">Belum ada data.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="bg-white border rounded p-4 shadow-sm">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <h2 class="text-lg font-semibold">Monitoring Berkas</h2>

                <form method="GET" class="flex flex-col sm:flex-row gap-2 items-end">
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Kecamatan</label>
                        <select name="kecamatan_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>" <?php if((string)($filters['kecamatan_id'] ?? '') === (string)$k->id): echo 'selected'; endif; ?>>
                                    <?php echo e($k->nama_kecamatan); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Dinas</label>
                        <select name="dinas_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $dinasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>" <?php if((string)($filters['dinas_id'] ?? '') === (string)$d->id): echo 'selected'; endif; ?>>
                                    <?php echo e($d->nama_dinas); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Layanan</label>
                        <select name="layanan_id" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $layananList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($l->id); ?>" <?php if((string)($filters['layanan_id'] ?? '') === (string)$l->id): echo 'selected'; endif; ?>>
                                    <?php echo e($l->nama_layanan); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Status</label>
                        <select name="status" class="border rounded px-2 py-1 text-sm">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = array_keys($statusCounts); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php if((string)($filters['status'] ?? '') === (string)$st): echo 'selected'; endif; ?>>
                                    <?php echo e($st); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex gap-2">
                        <button class="bg-blue-600 text-white px-3 py-1.5 rounded text-sm">Filter</button>
                        <a href="<?php echo e(route('dashboard')); ?>" class="border px-3 py-1.5 rounded text-sm">Reset</a>
                    </div>
                </form>
            </div>

            <div class="mt-4 overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                        <tr class="text-left text-gray-600">
                            <th class="py-2 pr-4">No Registrasi</th>
                            <th class="py-2 pr-4">Kecamatan</th>
                            <th class="py-2 pr-4">Layanan</th>
                            <th class="py-2 pr-4">Dinas</th>
                            <th class="py-2 pr-4">Status</th>
                            <th class="py-2 pr-4">Tanggal</th>
                            <th class="py-2 pr-4">SLA</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php $slaDaysLocal = (int)($slaDays ?? 3); ?>
                        <?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $op = $p->operator;
                                $dinasName = $op?->dinas?->nama_dinas ?? $op?->dinas_id ?? '-';
                                $isOver = $p->created_at && $p->status !== 'SELESAI' && $p->status !== 'DITOLAK' && $p->created_at < now()->subDays($slaDaysLocal);
                            ?>
                            <tr class="align-top">
                                <td class="py-2 pr-4 font-medium">
                                    <a href="<?php echo e(route('operator.permohonans.show', $p->id)); ?>" class="text-blue-700 hover:underline">
                                        <?php echo e($p->nomor_registrasi); ?>

                                    </a>
                                </td>
                                <td class="py-2 pr-4"><?php echo e($p->kecamatan->nama_kecamatan ?? '-'); ?></td>
                                <td class="py-2 pr-4"><?php echo e($p->layanan->nama_layanan ?? '-'); ?></td>
                                <td class="py-2 pr-4"><?php echo e($dinasName); ?></td>
                                <td class="py-2 pr-4">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs
                                        <?php if($p->status === 'SELESAI'): ?> bg-green-100 text-green-700
                                        <?php elseif($p->status === 'DITOLAK'): ?> bg-red-100 text-red-700
                                        <?php elseif($p->status === 'PERLU_PERBAIKAN'): ?> bg-yellow-100 text-yellow-800
                                        <?php else: ?> bg-blue-100 text-blue-700
                                        <?php endif; ?>">
                                        <?php echo e($p->status); ?>

                                    </span>
                                </td>
                                <td class="py-2 pr-4 text-gray-700"><?php echo e($p->created_at->format('Y-m-d')); ?></td>
                                <td class="py-2 pr-4">
                                    <?php if($isOver): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs bg-red-100 text-red-700 font-semibold">LEWAT</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700">OK</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($permohonans->isEmpty()): ?>
                            <tr>
                                <td colspan="7" class="py-4 text-gray-500">Tidak ada data.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <?php echo e($permohonans->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4)): ?>
<?php $attributes = $__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4; ?>
<?php unset($__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal180aa0cf8cb4c481783b7c169d3946f4)): ?>
<?php $component = $__componentOriginal180aa0cf8cb4c481783b7c169d3946f4; ?>
<?php unset($__componentOriginal180aa0cf8cb4c481783b7c169d3946f4); ?>
<?php endif; ?>

<?php /**PATH C:\Users\ZAID\Desktop\SIPATEN\sipaten-laravel\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>