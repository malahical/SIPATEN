<?php if (isset($component)) { $__componentOriginal180aa0cf8cb4c481783b7c169d3946f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sipaten-base-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sipaten-base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Dashboard Operator <?php $__env->endSlot(); ?>

    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold mb-4">Dashboard Operator</h1>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Total Pengajuan Hari Ini</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Dikirim</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
            <div class="bg-white border rounded p-4 shadow-sm">
                <div class="text-sm text-gray-500">Perlu Perbaikan</div>
                <div class="text-3xl font-bold text-blue-700">0</div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4)): ?>
<?php $attributes = $__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4; ?>
<?php unset($__attributesOriginal180aa0cf8cb4c481783b7c169d3946f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal180aa0cf8cb4c481783b7c169d3946f4)): ?>
<?php $component = $__componentOriginal180aa0cf8cb4c481783b7c169d3946f4; ?>
<?php unset($__componentOriginal180aa0cf8cb4c481783b7c169d3946f4); ?>
<?php endif; ?>

<?php /**PATH C:\Users\ZAID\Desktop\SIPATEN\sipaten-laravel\resources\views/dashboard/operator.blade.php ENDPATH**/ ?>