<header class="bg-white border-b border-gray-200">
    <div class="p-4 flex items-center justify-between">
        <div>
            <div class="text-sm text-gray-500">Halo,</div>
            <div class="font-semibold"><?php echo e(Auth::user()->name); ?></div>
        </div>
        <div class="text-sm text-gray-500">Role: <span class="font-medium text-blue-700"><?php echo e(Auth::user()->role); ?></span></div>
    </div>
</header>

<?php /**PATH C:\Users\ZAID\Desktop\SIPATEN\sipaten-laravel\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>