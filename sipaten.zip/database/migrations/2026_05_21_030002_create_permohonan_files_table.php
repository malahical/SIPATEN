<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permohonan_files', function (Blueprint $table) {
            $table->id();

            $table->foreignId('permohonan_id')->constrained('permohonans')->cascadeOnDelete();
            $table->string('nama_file');
            $table->string('jenis_file');
            $table->string('drive_file_id')->nullable();
            $table->string('drive_url')->nullable();

            $table->foreignId('uploaded_by')->constrained('users')->cascadeOnDelete();

            $table->timestamps();

            $table->index(['permohonan_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permohonan_files');
    }
};
