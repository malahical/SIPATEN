<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permohonans', function (Blueprint $table) {
            $table->id();

            $table->string('nomor_registrasi')->unique();
            $table->foreignId('layanan_id')->constrained()->cascadeOnDelete();
            $table->foreignId('kecamatan_id')->constrained()->cascadeOnDelete();
            $table->foreignId('operator_id')->constrained('users')->cascadeOnDelete();

            $table->string('nama_pemohon');
            $table->string('nik');
            $table->text('alamat');
            $table->string('no_wa_pemohon')->nullable();

            $table->string('status', 40)->default('DRAFT');

            $table->text('catatan_terakhir')->nullable();

            $table->timestamps();

            $table->index(['kecamatan_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permohonans');
    }
};
