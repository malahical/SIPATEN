<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('status_logs', function (Blueprint $table) {
            $table->id();

            $table->foreignId('permohonan_id')->constrained()->cascadeOnDelete();

            // Simpan status terbaru untuk histori
            $table->string('status', 40);

            $table->foreignId('changed_by')->constrained('users')->cascadeOnDelete();

            $table->text('catatan')->nullable();

            $table->timestamps();

            $table->index(['permohonan_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('status_logs');
    }
};
