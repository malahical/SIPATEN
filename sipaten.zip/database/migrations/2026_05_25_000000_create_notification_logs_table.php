<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_logs', function (Blueprint $table) {
            $table->id();

            $table->foreignId('permohonan_id')->constrained()->cascadeOnDelete();

            $table->string('event', 80);
            $table->string('to_number', 30);
            $table->text('message');

            $table->string('status', 20)->default('pending'); // pending|sent|failed
            $table->string('response_status', 20)->nullable();
            $table->longText('response_body')->nullable();

            $table->timestamp('sent_at')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_logs');
    }
};
