<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('billings', function (Blueprint $table) {
            $table->id();

            $table->foreignId('permohonan_id')->constrained()->cascadeOnDelete();
            $table->string('nomor_billing')->nullable();
            $table->string('jenis_billing')->nullable();

            $table->decimal('nominal', 15, 2)->nullable();
            $table->date('tanggal_billing')->nullable();
            $table->date('batas_bayar')->nullable();

            $table->string('status_bayar', 40)->default('BELUM_BAYAR');

            $table->text('catatan')->nullable();

            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();

            $table->timestamps();

            $table->index(['permohonan_id', 'status_bayar']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('billings');
    }
};
