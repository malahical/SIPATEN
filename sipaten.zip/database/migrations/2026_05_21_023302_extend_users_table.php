<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // role: operator/verifikator/admin
            $table->string('role')->default('operator');

            // master data scope
            $table->foreignId('kecamatan_id')->nullable()->constrained('kecamatans')->nullOnDelete();
            $table->foreignId('dinas_id')->nullable()->constrained('dinas')->nullOnDelete();

            // WhatsApp number
            $table->string('no_wa')->nullable();

            $table->boolean('is_active')->default(true);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('dinas_id');
            $table->dropConstrainedForeignId('kecamatan_id');

            $table->dropColumn([
                'role',
                'no_wa',
                'is_active',
            ]);
        });
    }
};

