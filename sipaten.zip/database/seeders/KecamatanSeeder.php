<?php

namespace Database\Seeders;

use App\Models\Kecamatan;
use Illuminate\Database\Seeder;

class KecamatanSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            ['nama_kecamatan' => 'Kecamatan A'],
            ['nama_kecamatan' => 'Kecamatan B'],
        ];

        foreach ($data as $item) {
            Kecamatan::updateOrCreate(
                ['nama_kecamatan' => $item['nama_kecamatan']],
                [
                    'alamat' => null,
                ]
            );
        }
    }
}
