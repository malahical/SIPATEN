<?php

namespace Database\Seeders;

use App\Models\Dinas;
use App\Models\Layanan;
use Illuminate\Database\Seeder;

class LayananSeeder extends Seeder
{
    public function run(): void
    {
        $dinases = Dinas::query()->orderBy('nama_dinas')->get();

        $fallbackDinasId = $dinases->first()?->id;

        $data = [
            ['nama_layanan' => 'Kartu Keluarga', 'jenis_layanan' => 'kependududukan'],
            ['nama_layanan' => 'KTP', 'jenis_layanan' => 'kependududukan'],
            ['nama_layanan' => 'Akta Kelahiran', 'jenis_layanan' => 'kependududukan'],
            ['nama_layanan' => 'Keterangan Usaha', 'jenis_layanan' => 'non_perizinan'],
            ['nama_layanan' => 'Bantuan Sosial', 'jenis_layanan' => 'bansos'],
            ['nama_layanan' => 'Pajak/Retribusi', 'jenis_layanan' => 'pajak_retribusi'],
            // layanan untuk dinas pertanian
            ['nama_layanan' => 'Bibit', 'jenis_layanan' => 'non_perizinan', 'dinas_nama' => 'Dinas Pertanian'],
        ];

        foreach ($data as $item) {
            $jenis = (string) $item['jenis_layanan'];

            // normalisasi "typo" yang mungkin terjadi
            if ($jenis === 'kependududukan') {
                $jenis = 'kependudukan';
            }

            $dinasId = $fallbackDinasId;

            // khusus layanan "Bibit" ditautkan ke dinas pertanian
            if (isset($item['dinas_nama'])) {
                $dinasPertanianId = $dinases
                    ->firstWhere('nama_dinas', (string) $item['dinas_nama'])
                    ?->id;

                if ($dinasPertanianId) {
                    $dinasId = $dinasPertanianId;
                }
            }

            if (!isset($item['dinas_nama'])) {
                $dinasId = $dinases->count() >= 2 ? $dinases->random()->id : $fallbackDinasId;
            }

            if (!$dinasId) {
                // jika dinas kosong, skip
                continue;
            }

            Layanan::updateOrCreate(
                ['nama_layanan' => $item['nama_layanan']],
                [
                    'jenis_layanan' => $jenis,
                    'dinas_id' => $dinasId,
                    'sla_hari' => 7,
                    'persyaratan' => null,
                    'is_active' => true,
                ]
            );
        }
    }
}
