<?php

namespace Database\Seeders;

use App\Models\Dinas;
use Illuminate\Database\Seeder;

class DinasSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            ['nama_dinas' => 'Dinas A', 'no_wa_admin' => null],
            ['nama_dinas' => 'Dinas B', 'no_wa_admin' => null],
            ['nama_dinas' => 'Dinas Pertanian', 'no_wa_admin' => null],
        ];

        foreach ($data as $item) {
            Dinas::updateOrCreate(
                ['nama_dinas' => $item['nama_dinas']],
                [
                    'no_wa_admin' => $item['no_wa_admin'],
                ]
            );
        }
    }
}
