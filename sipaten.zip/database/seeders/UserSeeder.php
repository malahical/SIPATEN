<?php

namespace Database\Seeders;

use App\Models\Dinas;
use App\Models\Kecamatan;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $kecamatanIds = Kecamatan::query()->pluck('id')->all();
        $dinasIds = Dinas::query()->pluck('id')->all();

        $operatorKecamatanId = $kecamatanIds[0] ?? null;
        $verifikatorDinasId = $dinasIds[0] ?? null;

        $users = [
            [
                'name' => 'Admin SIPATEN',
                'email' => 'admin@sipaten.test',
                'role' => 'admin',
                'kecamatan_id' => null,
                'dinas_id' => null,
            ],
            [
                'name' => 'Operator SIPATEN',
                'email' => 'operator@sipaten.test',
                'role' => 'operator',
                'kecamatan_id' => $operatorKecamatanId,
                'dinas_id' => null,
            ],
            [
                'name' => 'Verifikator SIPATEN',
                'email' => 'verifikator@sipaten.test',
                'role' => 'verifikator',
                'kecamatan_id' => null,
                'dinas_id' => $verifikatorDinasId,
            ],
        ];

        foreach ($users as $u) {
            User::updateOrCreate(
                ['email' => $u['email']],
                [
                    'name' => $u['name'],
                    'password' => Hash::make('password'),
                    'role' => $u['role'],
                    'is_active' => true,
                    'kecamatan_id' => $u['kecamatan_id'],
                    'dinas_id' => $u['dinas_id'],
                    'no_wa' => null,
                ]
            );
        }
    }
}
