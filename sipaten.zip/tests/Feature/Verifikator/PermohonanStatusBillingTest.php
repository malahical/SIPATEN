<?php

namespace Tests\Feature\Verifikator;

use App\Models\Billings;
use App\Models\Dinas;
use App\Models\Kecamatan;
use App\Models\Layanan;
use App\Models\Permohonan;
use App\Models\StatusLog;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

class PermohonanStatusBillingTest extends TestCase
{
    use RefreshDatabase;

    private function makeUserWithRoleAndScope(string $role, int $kecamatanId, int $dinasId): User
    {
        return User::create([
            'name' => Str::random(10),
            'email' => Str::random(10) . '@example.com',
            'password' => bcrypt('password'),
            'role' => $role,
            'kecamatan_id' => $kecamatanId,
            'dinas_id' => $dinasId,
            'is_active' => 1,
            'email_verified_at' => now(),
        ]);
    }

    private function makePermohonan(int $operatorId, int $kecamatanId, int $layananId, string $status = 'DRAFT'): Permohonan
    {
        return Permohonan::create([
            'nomor_registrasi' => 'SIPATEN-' . now()->format('Ymd') . '-' . random_int(1, 9999),
            'layanan_id' => $layananId,
            'kecamatan_id' => $kecamatanId,
            'operator_id' => $operatorId,
            'nama_pemohon' => 'Nama Pemohon',
            'nik' => (string) random_int(1000000000000, 9999999999999),
            'alamat' => 'Alamat',
            'no_wa_pemohon' => '6281234567890',
            'status' => $status,
            'catatan_terakhir' => null,
        ]);
    }

    private function makeBilling(int $permohonanId, int $createdById, string $statusBayar = 'BELUM_BAYAR'): Billings
    {
        return Billings::create([
            'permohonan_id' => $permohonanId,
            'nomor_billing' => 'B-' . Str::random(10),
            'jenis_billing' => 'BILLING-TEST',
            'nominal' => 10000,
            'tanggal_billing' => now(),
            'batas_bayar' => now()->addDays(7),
            'status_bayar' => $statusBayar,
            'catatan' => null,
            'created_by' => $createdById,
        ]);
    }

    public function test_valid_transition_creates_status_log()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Layanan Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 50000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');

        // MENUNGGU_PEMBAYARAN requires at least 1 billing for pajak_retribusi
        $this->makeBilling($permohonan->id, $verifikator->id, 'BELUM_BAYAR');

        $this->actingAs($verifikator);

        $resp = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'MENUNGGU_PEMBAYARAN',
            'catatan' => 'ok',
        ]);

        $resp->assertStatus(302);

        $this->assertDatabaseHas('status_logs', [
            'permohonan_id' => $permohonan->id,
            'catatan' => 'ok',
            'changed_by' => $verifikator->id,
        ]);

        $this->assertDatabaseHas('permohonans', [
            'id' => $permohonan->id,
            'status' => 'MENUNGGU_PEMBAYARAN',
        ]);
    }

    public function test_invalid_transition_returns_422()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Layanan Non Pajak',
            'jenis_layanan' => 'non_pajak',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 0,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');

        $this->actingAs($verifikator);

        // DIVERIFIKASI -> SELESAI is invalid based on mapping
        $resp = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'SELESAI',
            'catatan' => null,
        ]);

        $resp->assertStatus(422);
    }

    public function test_non_pajak_can_process_without_billing()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Non Pajak',
            'jenis_layanan' => 'non_pajak',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 0,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'MENUNGGU_PEMBAYARAN');

        $this->actingAs($verifikator);

        $resp = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'DIPROSES',
            'catatan' => null,
        ]);

        $resp->assertStatus(302);

        $this->assertDatabaseHas('permohonans', [
            'id' => $permohonan->id,
            'status' => 'DIPROSES',
        ]);
    }

    public function test_pajak_requires_billing_for_menunggu_pembayaran()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 10000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');

        $this->actingAs($verifikator);

        // No billing -> should 422
        $resp = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'MENUNGGU_PEMBAYARAN',
            'catatan' => 'x',
        ]);

        $resp->assertStatus(422);
    }

    public function test_pajak_can_menunggu_pembayaran_if_billing_exists()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 10000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');

        $this->makeBilling($permohonan->id, $verifikator->id, 'BELUM_BAYAR');

        $this->actingAs($verifikator);

        $resp = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'MENUNGGU_PEMBAYARAN',
            'catatan' => null,
        ]);

        $resp->assertStatus(302);

        $this->assertDatabaseHas('permohonans', [
            'id' => $permohonan->id,
            'status' => 'MENUNGGU_PEMBAYARAN',
        ]);
    }

    public function test_proses_selesai_not_locked_by_status_bayar()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 10000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'MENUNGGU_PEMBAYARAN');

        $this->makeBilling($permohonan->id, $verifikator->id, 'BELUM_BAYAR');

        $this->actingAs($verifikator);

        // MENUNGGU_PEMBAYARAN -> DIPROSES should be allowed even if status_bayar is BELUM_BAYAR
        $resp1 = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'DIPROSES',
            'catatan' => null,
        ]);
        $resp1->assertStatus(302);

        // DIPROSES -> SELESAI
        $resp2 = $this->post(route('verifikator.permohonans.updateStatus', $permohonan), [
            'status' => 'SELESAI',
            'catatan' => null,
        ]);
        $resp2->assertStatus(302);
    }

    public function test_update_status_bayar_valid_and_invalid()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 10000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');
        $billing = $this->makeBilling($permohonan->id, $verifikator->id, 'BELUM_BAYAR');

        $this->actingAs($verifikator);

        $valid = $this->post(route('verifikator.permohonans.billings.updateStatusBayar', $permohonan), [
            'status_bayar' => 'LUNAS',
        ]);
        $valid->assertStatus(302);

        $this->assertDatabaseHas('billings', [
            'id' => $billing->id,
            'status_bayar' => 'LUNAS',
        ]);

        $invalid = $this->post(route('verifikator.permohonans.billings.updateStatusBayar', $permohonan), [
            'status_bayar' => 'INVALID_STATUS',
        ]);
        $invalid->assertStatus(422);
    }

    public function test_update_status_bayar_billing_not_found_returns_404()
    {
        $kecamatan = Kecamatan::create(['nama_kecamatan' => 'Kec A']);
        $dinas = Dinas::create(['nama_dinas' => 'Dinas A']);
        $operator = $this->makeUserWithRoleAndScope('operator', $kecamatan->id, $dinas->id);
        $verifikator = $this->makeUserWithRoleAndScope('verifikator', $kecamatan->id, $dinas->id);

        $layanan = Layanan::create([
            'nama_layanan' => 'Pajak',
            'jenis_layanan' => 'pajak_retribusi',
            'dinas_id' => $dinas->id,
            'sla_hari' => 1,
            'is_active' => 1,
            'persyaratan' => null,
            'nominal' => 10000,
        ]);

        $permohonan = $this->makePermohonan($operator->id, $kecamatan->id, $layanan->id, 'DIVERIFIKASI');

        $this->actingAs($verifikator);

        $resp = $this->post(route('verifikator.permohonans.billings.updateStatusBayar', $permohonan), [
            'status_bayar' => 'LUNAS',
        ]);

        $resp->assertStatus(404);
    }

    public function test_navigation_basic_operator_and_verifikator_routes_are_accessible()
    {
        $this->get(route('dashboard'))->assertStatus(302); // should redirect to login or home
        $this->get(route('verifikator.dashboard'))->assertStatus(302);
        $this->get(route('operator.permohonans.index'))->assertStatus(302);
    }
}
