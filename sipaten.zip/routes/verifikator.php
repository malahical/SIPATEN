<?php

use App\Http\Controllers\Verifikator\PermohonanController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth', 'role:verifikator'])->group(function () {
    Route::get('/verifikator/dashboard', [PermohonanController::class, 'dashboard'])
        ->name('verifikator.dashboard');

    Route::get('/verifikator/permohonans', [PermohonanController::class, 'index'])
        ->name('verifikator.permohonans.index');

    Route::get('/verifikator/perlu-perbaikan', [PermohonanController::class, 'perluPerbaikan'])
        ->name('verifikator.perlu-perbaikan');

    Route::get('/verifikator/billing', [PermohonanController::class, 'billing'])
        ->name('verifikator.billing');

    Route::get('/verifikator/dokumen-selesai', [PermohonanController::class, 'dokumenSelesai'])
        ->name('verifikator.dokumen-selesai');

    Route::get('/verifikator/arsip', [PermohonanController::class, 'arsip'])
        ->name('verifikator.arsip');

    Route::get('/verifikator/permohonans/{permohonan}', [PermohonanController::class, 'show'])
        ->name('verifikator.permohonans.show');

    Route::post('/verifikator/permohonans/{permohonan}/status', [PermohonanController::class, 'updateStatus'])
        ->name('verifikator.permohonans.updateStatus');

    Route::post('/verifikator/permohonans/{permohonan}/billing', [PermohonanController::class, 'upsertBilling'])
        ->name('verifikator.permohonans.upsertBilling');

    Route::post('/verifikator/permohonans/{permohonan}/files/results', [PermohonanController::class, 'storeResultFile'])
        ->name('verifikator.permohonans.storeResultFile');

    // Update status bayar billing sederhana
    Route::post('/verifikator/permohonans/{permohonan}/billings/status-bayar', [PermohonanController::class, 'updateBillingStatusBayar'])
        ->name('verifikator.permohonans.billings.updateStatusBayar');
});
