<?php

use App\Http\Controllers\Operator\PermohonanController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth', 'verified', 'role:operator'])->group(function () {
    // Pengajuan Baru
    Route::get('/permohonans/create', [PermohonanController::class, 'create'])
        ->name('operator.permohonans.create');
    Route::post('/permohonans', [PermohonanController::class, 'store'])
        ->name('operator.permohonans.store');

    // Berkas saya
    Route::get('/permohonans', [PermohonanController::class, 'index'])
        ->name('operator.permohonans.index');

    // Detail permohonan
    Route::get('/permohonans/{permohonan}', [PermohonanController::class, 'show'])
        ->name('operator.permohonans.show');

    // Tracking status
    Route::get('/permohonans/{permohonan}/tracking', [PermohonanController::class, 'tracking'])
        ->name('operator.permohonans.tracking');

    // Cetak tanda terima
    Route::get('/permohonans/{permohonan}/receipt', [PermohonanController::class, 'receipt'])
        ->name('operator.permohonans.receipt');
});
