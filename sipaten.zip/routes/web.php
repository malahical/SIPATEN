<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/dashboard', \App\Http\Controllers\DashboardController::class)
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // CRUD master (admin)
    Route::middleware('role:admin')->group(function () {
        Route::resource('admin/kecamatans', \App\Http\Controllers\Admin\KecamatanController::class);
        Route::resource('admin/dinas', \App\Http\Controllers\Admin\DinasController::class);
        Route::resource('admin/layanans', \App\Http\Controllers\Admin\LayananController::class);
        Route::resource('admin/users', \App\Http\Controllers\Admin\UserController::class);
    });
});

require __DIR__.'/auth.php';

require __DIR__.'/operator.php';

require __DIR__.'/verifikator.php';
